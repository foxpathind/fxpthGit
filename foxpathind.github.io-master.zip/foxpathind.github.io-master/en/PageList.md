PageList.md
PagesList.txt
config.json
index.html
index.md
navigation.md
pages

./pages:
4AsNotes
4AsOperations
4AsProjects
4AsStrategy
CF
Ideas-Blog
Internet of things
Meetings Correspondance
Mobile App
PagesList.txt
Research
Scriv
TO READ
Templates
Training Education
Untitled.md
VooDooPad
WebsiteStrategy
about.md
createtech
download.md
imgs
meetings
presos
todo
uploads
wearables

./pages/4AsNotes:
AI_Review.rtf
AlisonMindshareEmail.md
CreativityStudies.md
Deltek-1.md
Deltek.md
EdTrainingConversation26Sept2014.md
Marc22Sep2014i.md
Marci Integrated initiatives.md
MarkAvnet.md
Notes.marked
PlatinumPartnerships.md
ReadMeNotes.taskpaper
RepresentativesPOV.txt
RunningNotes.txt
Strategic partnerships.md
Technology at the 4As.txt
Vertic.md
WorstAdExperiences.md
ZachPentel.md
advertising.md
justin_hendrix_-_nyc_media_lab.md
linkedin_personlaization_for_website.md
metis.md
nycmedialab2 (Foxpath DropBox's conflicted copy).md
nycmedialab2.md
portland_design.md
wordpress 4.md

./pages/4AsOperations:
DigitalSkillsInventoryProjectBrief.txt

./pages/4AsProjects:
RegistrationProject.md
issues-topics-knowledgedomains.md

./pages/4AsStrategy:

./pages/CF:
CF-CDO.md
CF4AsSig.md
My Markdown Architecture.md

./pages/Ideas-Blog:
Common Namespaces project.md
Common Namespaces project.opml
Energy-IoT-Data-Today.md
Ideas-Blog.marked
Outlander.md
Untitled.md
app mentality.md
commercial to personal.md
predictive shopping.md
test file.md

./pages/Internet of things:
Internet of things.marked
Note 3 févr. 2014.rtf
internet of things concept map.md
internetofthings.md

./pages/Meetings Correspondance:
Correspondance.marked

./pages/Mobile App:
Bizzabo Overview for Organizers.pdf - Dropbox.webloc
Mobile App Discussion.md

./pages/Research:
energy use, energy markets the internet of things.agentSearch

./pages/Research/energy use, energy markets the internet of things.agentSearch:
Archived.storage
DEVONagent-1.daMeta
DEVONagent-2.daMeta
DEVONagent-3.daMeta
DEVONagent-4.daMeta
DEVONagent-5.daMeta
DEVONagent-6.daMeta
DEVONagent-7.daMeta
DEVONagent-8.daMeta
DEVONagent-9.daMeta
Done.ulist
Log.plist
Objects.slist
QuickLook
Settings.plist
StopWords.plist

./pages/Research/energy use, energy markets the internet of things.agentSearch/QuickLook:
Preview.pdf

./pages/Scriv:
Draft
Scriv.marked

./pages/Scriv/Draft:
1 # This is the Title -3-.rtf
Draft.marked

./pages/TO READ:
4As_Final_LowRes (1).pdf
DGC Proposal_4As_FINAL.pdf
DGCcreds4As_final.pdf
PR Brief to Agencies_8-12-14.pdf

./pages/Templates:
Working Table.md

./pages/Training Education:

./pages/VooDooPad:
Untitled.vpdoc

./pages/VooDooPad/Untitled.vpdoc:
cache-b204a24b-f707-5316-8b83-5ee0aa5c8704
pages
properties.plist
storeinfo.plist
tags.plist

./pages/VooDooPad/Untitled.vpdoc/cache-b204a24b-f707-5316-8b83-5ee0aa5c8704:
sk.index
store.vpsqlite

./pages/VooDooPad/Untitled.vpdoc/pages:
b
c

./pages/VooDooPad/Untitled.vpdoc/pages/b:
bbb78d0a-bdf4-461a-a89e-b0ddef8a4370
bbb78d0a-bdf4-461a-a89e-b0ddef8a4370.plist
be7257be-ec52-46c1-a373-0274ce3cf1bb
be7257be-ec52-46c1-a373-0274ce3cf1bb.plist

./pages/VooDooPad/Untitled.vpdoc/pages/c:
c5af6286-2542-462d-b679-2f979d941e8a
c5af6286-2542-462d-b679-2f979d941e8a.plist

./pages/WebsiteStrategy:
Meet with Marci.md
My Notes
Taxonomy10Sep2014.md
Website Strategy Notes Ongoing.md
WebsiteInterviesIntro.md
WebsiteInterviewsIntro2.md
WebsiteStrategyMeetingNotes.md
WebsiteStrategyNote04Sep2014.md
WebsiteUpdate21Aug2014.md
web_strategy_and_ongoing_we.md

./pages/WebsiteStrategy/My Notes:
4A's & VML Weekly Regroup  starts August 14, 2014 at 11:00AM.html
4A's Strategy Meeting starts July 29, 2014 at 01:00PM.html
ARM Team participation.html
ARM Team participation.resources
Alison notes.html
Audience Personas.html
Content Audit report - 09 June 2014.html
Project Notes VML.html
VML SOW discussion.html
VML.html
Website2014 Features List.html
index.html

./pages/WebsiteStrategy/My Notes/ARM Team participation.resources:
4As member life cycle.oo3.zip

./pages/createtech:
ARCHIVE
BostonCouncilCall22Sept.md
CT Description Copy
CT_Update_04Oct2014.md
CT_Update_16Sept2014.md
CT_Update_22Sept2014.md
Committee
Conversations
CreateTech.marked
CreateTechSchemad.sublime-workspace
Email Promotion
Ideas notes
Proposals
Queries.md
Reference
Schedule
Sessions
Speakers
Sponsors
TableTemplate.md
Updates
Venue Logistics
Website
blog posts
rudina_-_update.md
updates.md

./pages/createtech/ARCHIVE:
CT_Update_15Sept2014.pdf

./pages/createtech/CT Description Copy:
Archive
CTmore directions.rtf
CreatTechDescription02Sept2014wSpeakers.md
CreatTechDescription26Sept2014wSpeakers.md
UweG-.md
createtech positioning.md
createtechAdCopy.rtf

./pages/createtech/CT Description Copy/Archive:
CreatTechDescription02Sept2014wSpeakers.doc
CreatTechDescription02Sept2014wSpeakers.docx
CreatTechDescription02Sept2014wSpeakers.pdf
CreatTechDescription02Sept2014wSpeakers.txt
CreatTechDescription20Aug2014wSpeakers.doc
CreatTechDescription20Aug2014wSpeakers.rtf
CreateTechDescription20Aug2014.md
creativity_and_the_internet_of_everything-_new_abilities,_new_interfaces,_new_design,_new_behaviors,_new_data..md

./pages/createtech/Committee:
Committee.md

./pages/createtech/Conversations:
AlanSchulman.md
AndrewMason.md
ByronEllis-CTO- Spongecell.md
JohnCain.md
Keith Johnston.md
MikeBakerConversation.md
hush_call.md
mindshare.md

./pages/createtech/Email Promotion:
CTEmailCopy.md
CTlotsofphrases.md
CTlotsofphrases.rtf

./pages/createtech/Ideas notes:
createtech-notes-sept.md

./pages/createtech/Proposals:

./pages/createtech/Reference:

./pages/createtech/Schedule:
featured_speakers.md

./pages/createtech/Sessions:
ATTManMade.md
Biohacking-Bulletproof.md
CTIA.md
CreateTech 2014 topic development ideas.md
DDBMcDonalds.md
Emailcopy.md
FakeLove.md
Memi_FashionTech.md
MikeDigiovani.md
MonotypeCall.md
Powell08Sep2014.md
SeldonMontiero.md
ToolIBMOlgilvy.md
jason_levy.md
monotype.md

./pages/createtech/Speakers:
BenMalbon.md
BenMalbon.rtf
CreateTech Checkin Email.md
Follow ups CreateTech.md
JasonLevy.md
JasonLevy.rtf
KatieLondon.md
KatieLondon.rtf
MikeDigiovanni.md
MikeDigiovanni.rtf
RudinaSeseri.md
RudinaSeseri.rtf
Spongecell.webloc

./pages/createtech/Sponsors:

./pages/createtech/Updates:
CT_Update_16Sept2014.pdf
CreateTech Progress.markdown

./pages/createtech/Venue Logistics:
CreateTechAV.md

./pages/createtech/Website:
CreateTech Schema Code.md
CreateTech Website.md

./pages/createtech/blog posts:
Blog posts.md

./pages/imgs:
4As-CreateTech-2014-468x60-1b6wx.gif

./pages/meetings:
TaxonomyHBR.md
Xchange23September.md

./pages/presos:
SLIDES.md
TEST-TechTalk.md
Techtalk2014-B2Bversion.md
Techtalk2014-B2BversionSLIDES2.md

./pages/todo:
ToDo - September 12.taskpaper
ToDo - September 12a.taskpaper
ToDos_END_2014.md
TodoSeptember2014.todo.ft..ft

./pages/uploads:
documents
images
movies
music
pdf
presentations

./pages/uploads/documents:

./pages/uploads/images:

./pages/uploads/movies:

./pages/uploads/music:

./pages/uploads/pdf:

./pages/uploads/presentations:

./pages/wearables:
future-of-wearable-tech-140108140946-phpapp02.rtf
wearables.marked
