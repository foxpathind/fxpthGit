Hi Alison,

Mindshare is one of the agencies that will be participating in CreateTech this year. They have a new unit devoted to the "internet of things"  a rubric that includes wearable tech for health and fitness, connected cars, connected appliances and homes. This has definitely been one of the hottest topics in tech and business this year and the subject of many mergers and acquisitions among all the top technology companies.

They have proposed to do original research to be delivered at the conference  and with their client  [*MapMyFitness*](http://www.mapmyfitness.com/) to create an activity for conference attendees to participate in, I guess using their devices and gathering some running data.

All of the press and PR dimensions of this are out of my depth and I'd like to go over this with you and talk about next steps and whether you'd like to be directly involved (Hope so!)

Let me know when you have a moment. 