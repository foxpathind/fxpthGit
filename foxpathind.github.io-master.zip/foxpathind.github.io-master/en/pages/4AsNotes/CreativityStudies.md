I got authorization to pay for the hotel for Createtech, so I booked a room at the Hyatt. Yay! Hoping you'll be able to comp me for the conference, or find something I can do to contribute in kind; present, panel, etc…

Curiosity index. Looks like the major study is http://www.ncbi.nlm.nih.gov/pmc/articles/PMC2770180/ and the 10 question inventory (test) is http://psychfaculty.gmu.edu/kashdan/CEI-II.pdf .
Interesting reads. The inventory seems to be both valid and consistent, and maps well to other psych tests. It's listed as an assessment tool at the UPenn Positive Psychology Center, which is the big name in the field http://www.ppc.sas.upenn.edu/ppquestionnaires.htm 

I think the questions are too obvious to give directly to job applicants but it might be possible to reframe these questions as "interview type" conversations to have, as part of the interview process vs. an actual test. "So, tell me a bit about how you approached that new thing you just told me about…"

I also think it'd be interesting to see how the ad industry at large would score (anonymously and with people already working, not job applicants).

Let's talk about how we might use this!

And please let me know about next steps on the Educational group as well.

And i'm going to start reading those studies you linked to. Looks like good "sitting down with a lot of coffee" reading :)


Please send that article you mentioned from the ACM journal.
Methods of Curation to evaluate Information-Based Ideation
Bonus file ;) Embodied Cognition, a field guide

https://www.dropbox.com/s/71u0uavr9965qfg/Information-basedIdeation-a14-kerne.pdf?dl=0