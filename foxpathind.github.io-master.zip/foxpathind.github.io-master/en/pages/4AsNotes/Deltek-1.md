Traffic LIVE (Sonar acquired by Deltek)
Maconomy
	- WPP
	- Publicis
Competitors
	- AtTask
	- Advantage
	- Workamajig
Partner moving forward
Agency workflow software
	- Global 
	- WPP
	- IPG
Market awareness in the US

Targets
- Indepenents
- InHouse
	- Barclays
	- Nike

Large Network competitors
	- Excel


Traffic Live
Went to the ANA conference
- met with clients	


Cut out the finance when there is a ERP system

Don't do media buying

Talk to to Tanya about

- Doc Store
- Chat
- Digital asset management 
	- North Plains
	- Open API
	- Deltek DMA product


Java/Adobe Air
Data centers in UK
