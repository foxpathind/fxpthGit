## Training and Education ##

### Programs ###

- IPA/Partnership
- Millennial program
- Assessment
- Our current offerings
- Metis


### Metis ###

- Data Science
- Product design - UX
- Full stack
- Sponsorship
	- still interested
	- create the evaluation and sponsor

#### Evaluation ####

- would require our involvement

### Advisory committee ###

- Assemble the committee
- Not just the working on the assessment
- Assessment then followup?


### Resources ###

- IPA is done, tuned to our industry - our required resources: 25%
- 4A's is reviewing the material and then see what the gap and opportunity
- We need to build the group
- What we have is pretty random
	- Based on consultants who come to us
	- Not a designed curriculum
- We need to look at the current offering and do the gap analysis

### Next Step ###

- Talk to Mark 
- Candidates for the advisory group

### Timeline Realistic ###

- Talk in January
- Our industry will shut down in 10 weeks
- 



