## December 1, 2014 - 10:05 AM

# New reporting law
- reporting that you DO have insurance
- **Will need to file with taxes**

# Rate Demographics
- bad profile for this group
- regional fees

# Aetna
- increase in premium rate
- no change in coverage
- slight changes in deductible

# Dental 
- increase in premium rate

# Aetna
- navigator
- discount programs
	- RX at home
		- 90day supply
		- double dose scored tablets
- aetna app
	- history of medications
	- id card
	- look up claims
	- drug costs


# HSA
- Debit card
- won't discriminate on eligible versus ineligible charges
- only access to what is deposit in the account **at time of service!!!**
	- can pay yourself back
- $6000 deductible
- pharmacy 
- out of network doesn't use the aetna negotiated rates
	- balance billing
- taxed on deposit not interest
- HSA bank 
	- max deposit $6650
- covers all costs
- HSA can used for lng term care
- HSA can be used for Cobra
- get eligible expenses slide
- keep all receipts!!!


## over 65
- can open high deductible
- don't use HSA , can use FSA


# Dental Benefits - United health care - **myuhcdental.com**
- no change to program
- new rates though
- network has contracted rates
- ask "participating in Untied Health Care"
- **max multiplier** - rollover of unused max benefit
- adult orthodonture


# Vision - EyeMed - **eyemedvisioncare.com**
- in network only benefit 
- use for perscription at least, to take advantage
- **do retinal imaging!! - predictive** - mostly covered 
- frames every two years
- sun glasses!
- **eyemed card**
- website 
- iPhone app

# FSA (not us!)
- iPhone app is really great!



## Questions
- MUST re-enroll in the spending programs
- what was last years benefit?


- Get a consolidated report of health care situation



