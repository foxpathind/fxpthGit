## Marci ##

### Education ###

- Walkthrough the assessment document with Singleton
- Convene the advisory group

### Mobile ###

### CreateTech ###
- Times 8:00 - 5:30
- Help 

### Database ###

### VML ###

- Interviews
- Email for the survey
- Process
	- Strategy in the end of the year
	- 