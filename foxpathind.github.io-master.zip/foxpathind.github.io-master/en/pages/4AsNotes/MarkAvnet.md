### Reply:
Test   

* _Fast – found a little more about it – the Future of Advertising Stakeholders -  http://adage.com/article/news/fast-forward-p-g-s-summit-signals-future-broad-industry-coalition-formed/64742/_
	* Fasciating. Mike Donahue from the 4A's was part of that original group and has talked about it. Maybe we'll get a little history to start a new one.

* _I'd love to be part of the Agency Education and Training thing, and would be happy to chair (or co-chair)._
	* I'm going to write up an outline of the talks now going on at the 4A's and then I think the next step is to identify a small group to invite to a preliminary discussion.
	* When talking to the training firm who may be one of our partners [Metis/Kaplan](http://www.thisismetis.com/) they are very interested in understanding:
		* Framework  best value for the agencies
		* Framework for the evaluation/digital assessment tool. They do work now with tools to help them identify the best candidates for their classes today. Adding our input from the industry plus their experience may be very helpful.


* _We also talked about a digital assessment tool, and a curiosity assessment tool. I'll check through the psych literature and see if i can find anything for the curiosity one – there's got to be something (although it'll probably be a 250 question survey)._
	- See above


* _Re: Createtech – do you know which hotel would be a good one to stay at? Are there any block rates through 4As?_
	* Have to get on that myself!! Think Cambridge though. We _MAY_ end up getting a block of rooms. Will let you know soon before prces go up.
		* Kendall Hotel, close to venue, boutique - [http://kendallhotel.com/](http://kendallhotel.com/)
		* Hyatt Regency, Cambridge, cheaper, prepaid, I'm probably going to end up there. -  [http://cambridge.hyatt.com/](http://cambridge.hyatt.com/)
	

* _Please send that article you mentioned from the ACM journal._
	- [Methods of Curation to evaluate Information-Based Ideation](https://www.dropbox.com/s/71u0uavr9965qfg/Information-basedIdeation-a14-kerne.pdf?dl=0)
	- Bonus file ;) [Embodied Cognition, a field guide](https://www.dropbox.com/s/k57knlou22a0p36/EmbodiedCognitionAfieldGuide.pdf?dl=0)
----

## Chick's sketchy notes from our conversation. To be continued...
### "Fast conference"

* Scenario planning session
* Finding the facets to explore:
	* Media formats, channels and technology
	* Marketing technology as digital nervous system
	* Personalized product manufacturing
	* Social Tech - habits, behaviors 
	* Technology "comfort food - the psychology of adoption and use
	
* MA: [Fast – found a little more about it – the Future of Advertising Stakeholders ](http://adage.com/article/news/fast-forward-p-g-s-summit-signals-future-broad-industry-coalition-formed/64742/)




###Agency Education & training  symposium/committee/working group
* **Note:** *This may come up very quickly. Talking to a couple of people here who are very interested. Maybe you "chair" it?*

* MA: I'd love to be part of the Agency Education and Training thing, and would be happy to chair (or co-chair).

* MA: We also talked about a digital assessment tool, and a curiosity assessment tool. I'll check through the psych literature and see if i can find anything for the curiosity one – there's got to be something (although it'll probably be a 250 question survey).

* Training - many programs can meet the requirement
	* Certify the program or course not just 4A's offerings
		* "The 360i training program is 4As approved education program""
	* Examples:
		* HyperIsland
		* Agency training
		* Miami Ad School
		* VCU Brand Center
		* University programs advertising and relevant "other" 
			* information science
* Professionalize which agency roles? 
	* Think carefully 
	* What would certification and possibly professional credits mean to agencies and individuals
*  

####Reference 360i programs (incomplete notes)
* How to fit into the agency
	* professional dev
		* emerging managers
		* strategy
		* ideation
	* personal
		* yoga
		* idea/trend group jams
	*  employees


```
perl
# Demonstrate Syntax Highlighting if you link to highlight.js #
# http://softwaremaniacs.org/soft/highlight/en/
print "Hello, world!\n";
$a = 0;
while ($a < 10) {
print "$a...\n";
$a++;
}
```


