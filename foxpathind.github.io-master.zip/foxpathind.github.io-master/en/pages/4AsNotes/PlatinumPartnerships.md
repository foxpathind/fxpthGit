## Platinum Partnerships: ##

@Meeting


- AOL
- ATT
- Deltek - meeting set for 
- Klout
- Mashable - unhappy with their ANA
	- Like parties
	- Board meetings
	- Chairmans dinners
	- Innovation day
	- speed tech demos
- Metis
- LinkedIn
	- John Williams
- Adobe
- Rubicon
- Collective
- Time
	- Mark Ford
	- $175
		- Custom events
		- Platinum light
	- CreateTech
		- Too tech savvy audience
- Twitter
- Centro
- Datalogix
- Simulmedia
- Teleamerica CrossMedia