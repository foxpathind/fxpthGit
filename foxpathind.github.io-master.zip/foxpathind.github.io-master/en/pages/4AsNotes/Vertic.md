·  Increasing the power of our profiles
o Link LinkedIn profile to 4A's Profile
§ Use "Log in with LinkedIn"
§ Present industry connections and potential connections through the 4A's profile page
§ Synchronize company profiles to 4A's directory (netForum)
§ Connect to collegues at same company
·  To learn:
o What data is exchanged?
o Can changes to a record be "followed" (example: change agency)
 
Still need to think about the customized experience side of this. Definitely some possibilities but we'd be needing to add other audience factors to what would be gleaned from a LinkedIn profile.


## Vertic

* Ad agency
* Strategy
* Creativity 

####LinkedIn 

* data for targeted
* access to user the data
* build experience off the LinkedIn data
* AARP - Life reimagined
	* Careers 
	* Sync platforms between LinkedIn and AARP
	* Content contributions
		* articles
	* Career connect
		* Step by step process for moving between business
		* Skills inventory
* Microsoft
	* Targeting CXOs
	* Providing content
	* Connect with LinkedIn
		* Personalizes the information even documents
		* 
