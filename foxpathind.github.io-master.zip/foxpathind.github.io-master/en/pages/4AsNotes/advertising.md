[@ title of the file]

## advertising 
- as support of media/service
- as communication
- as industry
	- part of an enterprise activities
	- regulated by governments
	- source of employment
- as a business
	- collection of services
	- collection of professions
- another aspect
	- add another leaf here
	- test