#principles
* agencies people will not self organize around a task
* best to test ideas and work with them
	* must be sufficiently developed to get valuable feedback
	* must gamble some development time
	* quarterly reviews
* important to design engagement tools
	* documents
	* surveys
	* reviews and feedback
	* logins and access an issue
		* login with social login easiest?
		* email addresses dont always work between workmand social
		* login with your 4As id?
* there should be an internal process for issue identification
	* kitchen cabinet
	* dept heads
	* test with ARM
	* research methodology
		* critical mass of attention
	* concept map?
	* pre sell?
		* webinar/workshop to discuss?
		* online unconferences?
	
