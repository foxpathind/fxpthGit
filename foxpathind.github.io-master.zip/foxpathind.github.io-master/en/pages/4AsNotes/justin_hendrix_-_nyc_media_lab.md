# Justin Hendrix - NYC Media Lab
## Dec 2012
- from Economist
- Tech commercializtion 
- Innovaton ecosystem
- Media vs Creative like in media publishing/journalism
- Publicis has joined 
	- consortium
- step back from research
	- head to UX
	- doing things SVA, NYU, etc.
- the lab has advanced
	- still very much a start up
	- we're looking for opportunities 