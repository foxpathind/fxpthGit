# LinkedIn personlaization for website
## Karl Vontz, Chick, Alison F
### 4A's LinkedIn strategy

- Increasing the power of our profiles
	- Link LinkedIn profile to 4A's Profile
		- Use "Log in with LinkedIn"
		- Present industry connections and potential connections through the 4A's profile page
		- Synchronize company profiles to 4A's directory (netForum)
		- Connect to collegues at same company
- To learn:
	- What data is exchanged?
	- Can changes to a record be "followed" (example: change agency)
	
		

Still need to think about the customized experience side of this. 

Definitely some possibilities but we'd be needing to add other audience factors to what would be gleaned from a LinkedIn profile.

	
