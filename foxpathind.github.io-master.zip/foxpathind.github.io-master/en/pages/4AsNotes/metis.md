## Metis ##


## Call 5 Sept 2014 ##

#### Background Qualifications For Courses ####

* "who will be successful" and/or people who can be "unlocked"
* data science
	* experience with coding
	* curiosity
* frontend  UX
	* visual designers to UX designers
	* also make them front prototyping

#### Test Our Hypotheses ####

* conversation with agency advisory
* time commitment
	* output/outcome
		* time commitment is related to outcome
	* entry level options
* we can design this when we understand
	* practical time commitments
	* plus meaningful outcomes
	* equals mission criteria 

#### Goals ####

* Advisory group meeting in early October
	* Framework  best value for the agencies
	* Framework for the evaluation
* Metis to bring some of the programming heads from UX, Dev and Data Science

#### 4A's Facets ####

LB Business side
AF programming side
SB training side


---



   - Talking points
	  * evaluation of digital savvy personnel
		 * **digital production-related**
			 * Design tools - Adobe Creative Suite
			 * Quality assurance
			 * version control
			 * digital asset management
		 * **marketing and strategy related**
			 * social media marketing capabilities
			 * multi screen strategies
		 * **future oriented, proactive**
			 *  interested and follows trends
			 *  looks for connections to marketing needs/activities
		 * **specific skills**
			* programming
				* front end script editing
					* html, css, javascript
				* prototyping
				* full stack web development
			* design, UX, visualization
			* systems admin
			* database design and SQL (MS,MySQL,PostGres etc)
			* media ad operations
			* cms 
				* configuration
				* administration
				* workflow/editing
			* analytics
				* statistcs 
				* tools

   - Advisory group proposal for education/training offering

