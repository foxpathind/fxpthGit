Nycmedialab
Internet time matches Tv time 
Excess capacity in residential areas can't be used
Use for telecommuting?
Time Warner 

