Nycmedialab
Internet time matches Tv time 
Excess capacity in residential areas can't be used
Use for telecommuting?

Publicis
Razorfish,MRY,Vivaki,Digitas

Future of retail
Drone commerce, rifd
What's happening at point of sale.
Waze alerts commercial
25000

Rlukedubois


connective media program
cornell tech 
@informor
graduate education for the connected age
now at google
100 students
jacobs institute
	non profit
	hub
		connective media
		healtier life
		built environment
	connective media
		media, infomation, communication
		thecitybeat.org
		masters 2 year
			tech
			human social aspect
			entrepreneurship
			studio approach
	seen.co
		feeds media real time
mor.naaman
bitly/connmediams

brown insitute colombia
media innovation
data, algorithm,  as story, discovery
fellowship, magic grants

bushwig
identity curation
brooklyn drag archive
the drag arts

city beat

nyc media center

science surveyor on deadline
	consesus later
	temporal reference. !! mentions
	funding layer
art++
	index objects

support journalism students for

domain specific programming language

computation and jouranlism symposium

markh@colombia .edu

tell stories about the futures
g.b.

roomba
10 million of them
inner life

understanding our life with
fascination with "coming to life" making things come to life
the gollum
the morality of making comi to life

thing that is invisible and powerful, the latest tech
in the 17th century the tech appears

	clocks
	automotons
		le carnard 
		lifelike
		voltaire glory for france
	electricity
		pure life force (versus blood)
	steam
		power a body, steam men
		animating force
	ww1 - machines of death
		imagination , life, 
		questions what are we making
	rossums universal robot 1921 capek
		seen about social commentary
		runs in nyc for a long time
		robot-ness, life making
		
the 4 problems
	the body, gendered, raced
	what body do need
	what does it do
	what is it doing, what does it look like
	agency, autonomy
		challenges when granting agency
		as you start how far should you go
	inner life of robots
		a body, a purpose and agency what is that
		all stories: this cant end well
		m.mori
			the buddha in the robot
			find higher intentionality
			robots external,y our angst about power
		anxieties about tech is about ourselves
	promise and pitfalls
		making culture. (our living in a culture)
		and mirrors of our intentions of a moment
		not artifacts but the meaning structures were making

		
		
		



	


		


