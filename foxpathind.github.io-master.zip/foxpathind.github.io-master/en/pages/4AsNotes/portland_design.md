## Portland design
- http://www.secondstory.com/
- http://urbanairship.com/industries
- http://www.hugekingcoyle.com/
