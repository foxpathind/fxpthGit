## Marci
- $11,000/month

## Website
- VML
- eMedia

- Timeline 
	- Marci
		- ???
	- Carol
		-???
	- eMedia 
		- $5,500/month
	- VML
		$135K
		
- Taxonmy
	- Leader ?
		- VML
		- eMedia


- 