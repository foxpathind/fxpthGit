# 4A's Video Strategy

December 2, 2014 - 2:14 PM

- Video webinars
-  4 to 6 20 minutes, packaged 
- On DEmnad ann/or webcast



-----

- Siberian Films
	- Creative Services Video opticals
	- Production solutions
	- Storage, archival and rettrieval

## Tasks

- Catalog Video assets
	- Storage
- Publishing
	- Web 
- Editing


## The challenges

- We now need video content all publishing
	- Events
	- Testimonials
	- Webinars
- Quicker turnaround
- Too many locations
- Consistent quality
- Catalog
- Training and webinars


## Webinars

- Posted to Viddler


## Start

- Production - master plan
	- **Budget**
	- We need to start with what production
	- What is the video planning check list
	- **Master schedule plan**
		- Events
		- Webinars
		- Editorial
	- Must include the end use, destination
	- Bundle production resources
	- Standards
	- Log/script notes

-Storage 
	- Where do you want to publish them
		- Publish design
			- Brightcove
			- Sketches
	- Unified repository
	- Transcoding	
	- Catalog

- Publishing
	- Editing
	- Rights
		- Speakers
		- Music
	- Metrics

## Survey

- What has been successful?
- What resources have we used
	

## Notes

- Advertisers
- Training producers at agencies
 

## Do NOW!

- Downloads videos
- Create storage and catalog for short term
- Inventory
	- Where is it?
- Do we have strategy for video delivery, VML
	- Sketch use cases
- Make the master schedule
- Book out our studio??? - Revenue
- Log while shooting
	- Tweet log 
	- Script notes


## Notes

- Advertisers
- Training producers at agencies
- Storage, logging, retrieval, working in lo-res
	- AVID, Adobe,  



