## Data Quality

- Inaccuracy
- Completeness
- Inconsistency
- Staff knowledge
- Project process



## Operations
- Industry census 
- Communications targeting
- 

## Member experience
- Registration

