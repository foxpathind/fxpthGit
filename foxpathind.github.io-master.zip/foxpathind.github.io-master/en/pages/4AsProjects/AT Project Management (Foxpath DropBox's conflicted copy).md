#Abelson Taylor


Following on the heels of the above, where possible provide examples.  Case in point when I mentioned to him part of our approach around PM would be to acknowledge that they have done a lot of work to find the right PM software/tools but that theory and practice can be two very different things and they can hit some real bumps in the road as they start to implement the plan - he noted that we should call out what some meeting has been leading the charge on Project Management so good to spend some time on this.

* Respecting project management process 
	* authority who owns the project 
	* scope
	* communications 
	* documentation
* Agreed upon rules
	* client
		* project management synchrony 
		* reviews, approvals, acceptance
	* partners
	* tools
	* compliance
* Software
	* requirements
		* tracking hours?
		* reporting
	* use the tool
	* data entry
		* email
		* time needed
		* compliance
	* differentiated  access
	* tasks and assignment granularity 
	* narrative blog versus task kanban 
	* 
