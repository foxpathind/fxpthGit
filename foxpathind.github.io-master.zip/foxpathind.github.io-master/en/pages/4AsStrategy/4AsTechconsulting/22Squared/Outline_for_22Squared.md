# 22Squared Intro #

##  ##

- Now 55% digital
	- Digital
	- Social
	- Analytics
- Revenue not keeping up with the work
- Integrated story
	- Friendship model
		- Brand relationships are like personal relationships
		- social is leading growth - HomeDepot
	- Suntrust came bak after Digitas
	- New club membership bank
	- New client digital, web, analytic
	- Offering 
		- Social - 20 group but
		- Strategy group
			- vision 
			- 
		- Creative department
			- New
		- Analytics
			- Where should it go
		- Media
			- Horizon
			- Big part of the suntrust win back
			- Q: where does media tech
				- Head of media owns relationship
				- IT makes it work
			- Departments own the relationships, IT makes it work
	- Culture
		- 50% results - 50% Cuture
		- Collaboration
		- Independence!
		- Talent Quest - should we evaluate
	- IT
		- Support - outside works most of the time
		- Storage - 
		- Data governance
	- Content
		- Storytelling
			- content visualists and writing
			- agile filming etc
		- Production
	- Analytics
		- Part of every pitch
		- Need to get to Media Mix Modeling
			- even horizon can't offer
			- Analect - but too expensive
		- Skill gap, can't tell emotional stories
			- Advertsing is emotional storytelling
		- Clients want to talk about predictive but not there yet
		- Tableau based dash boards
		- Toyota has sales data
			- Facebook page for each dealer
			- Facebook ads 
		- Data governance
			- Security yes
			- Data governance
				- Protections
		- CRM practice
			- Exact Target/Saleforce
			- What are other agencies doing here?


## 4A's Analytics ##

-  Holding companies buy big product then try and amortize
-  Home grown per client with Tableau
-  Anametrix has a lot of this, allows working with R etc.
	-  Maybe a scalability gap
	-  Media, research, technology, analytics
		-  Media technology starting to rule the relationship. builds the platforms
-  Pricing 
	-  automation
	-  Q: @sal - what are your pricing methodologies
	-  A: Agreements AOR, scope, hours and fee
	-  A: Clients are not there in their assessment of how marketing has changed
	-  Using 3rd parties but their is time converting to 22squared
		-  like old production costs
-  CRM
	-  A: I think of it a media channle
	-  More than just media, could sit anywhere
		-  center of excellence - advise on all accounts
		-  

## 4A's Content ##

-  


# 4As Technology Offerings #





## Committees and Task Forces
- IT
	- Committee Response gathering
		- Backup systems
		- Virus
- Creative Technologies
	- Integrated production topics
- Digital Advertising
	- Media Group
	- Policy and ad ops
- Production
	- Covers mostly video production policy issues
Data Security

## Training and webinars


## Surveys

##Task Forces
- Project management
- Data Security
- Patent Trolling
- Talent development
	- Webinars
	- 



## Issues we follow
 - Data security 

##Facets
- Tools
 - Policies & Governance
###Best practices
## Studies


# Notes from 4A's Staff


Moliie Schedule:


12-12:15  - Lunch/Introductions
12:15-12:30 - 22squared update by Mike Grindell
12:30- 1:00 - Analytics (Terry - Bill will you be joining as well?)
1:00 - 1:30 - Content (Jules, Sal)
1:30 - 2:00 - IT (Chick)






Attachment 1 - "DiSC Assessment". I recently had a lengthy conversation on the topic of Agency Operation with the Associate Director of Account Service at Spawn in Anchorage. Resource and Workflow Management came up and led to agreement that developing better practices in agency operations should include an early "introspective" assessment by senior agency management of key factors that effect resources and workflow, for example, skill levels of existing staff, client needs, and agency service offerings ... to name just three.  

This assessment (a "reality check") should be the basis of determining how an agency should best plan for these areas. 

I was surprised to hear that this relatively small agency had gone a long way with it. They went through a staff personality assessment exercise using the "DiSC" approach.  In another example, I met several weeks with the Managing Partner, PMO at Rosetta, a 1,000 person agency and found that his senior management team made similar assessments of its staff. In this case, the agency used a tool created by that individual.

Attachments 2 & 3 - my notes to two events, one held at BSSP in Sausalito on March 4th and the second at McCann Worldgroup in NYC on April 23rd. 
The theme of the two meetings was "Structuring Agency Functions: The Intersection of Account, Project, and Production Managements". (Please excuse the format.)

Attachments 4 & 5 - related word docs to attachments 2 &3. NOTE: NOT FOR DISTRIBUTION - meeting participants are identified.

Attachment 6 - 4A's "Wiki" - "Agency Best Practices - Project-Based Assignments"

Attachment 7 - 4A's PM Matters - "Managing Global-Virtual Account Teams"

Attachment 8 - 4A's 2011 PM NYC Workshop. Workshops also held in Chicago and Atlanta.

Other:

Attachment 9 - "Agency 2020" 

Advantage Software - PM capabilities demo with several 4A's members & Ellen Coulter, Advantage Pres.

Digital PM Summit 2014 in Austin - I attended (Non-4A's Event)

4A's Digital Project Management Roundtable - August 14, 2014 



