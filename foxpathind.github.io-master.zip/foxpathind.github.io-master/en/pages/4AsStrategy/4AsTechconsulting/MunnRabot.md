## Munn Rabot ##

- Can't even use tape now reliability
- Video and photo files
- Maintain what we need 
- Phototographers
	- much bigger files
- Video
	- P2 category cameras
- Iterations
	- 30 steps
		- super fat payload
		- 10X original payload
- Buying thunderbolt drives
- RAID boxes
- Then standard box
- Macs not agreeing with Symantec agent
- we are a single site company
	- but security of files is the issues
- 