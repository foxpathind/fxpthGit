# CF - CDO
## Backgrounds
- Interactive multimedia producer 1983-1986
- Createive technologies management 1986-1999
- Interaction design and programming 1989-2000s
- Interactive practive team building, process management, new business
## Companies
- Self employed
- Citibank
- FCB New York
- Wechsler
## 4A's responsibilties
- Manage the internal digital strategy and major projects
	- Interanl and exteranl facing
	- Currently we have a major web redesign reengineering project including 
		- a new CMS, 
		- integration with our AMS
		- flexible mobile ready design
		- better usability to deliver organization benefits
- Manage the development team
- Periodically consult with members on specific digital challenges
	- Data security and agency responsibilites
	- Managing client expectations in the move to project-led work
	- Identify prominent interaction design or technology resources for agency gatherings
- Provide community resource for technologists working in agencies
	- CreateTech
		- Themes
			- Making equal thinking
			- Artificial intelligence and creativity
			- Experience design for the internet of everything
		- Push out into the future for the knowledgeable agency person
		- Place for "premeptive, speculative ideation"
			- It's not practical yet, but the pace of change demands engagement
		- Meet your peers