**Chick Foxgrover / 4A's**
Chief Digital Officer
1065 Avenue of the Americas / 16th Floor / New York / NY 10018
212 850 0788 tel
[www.aaaa.org ](http://www.aaaa.org )
// 4A's CreateTech 2014 / no edges : humans machines environments //
// [createtech.aaaa.org](http://createtech.aaaa.org) / Nov 12-13 in Boston //