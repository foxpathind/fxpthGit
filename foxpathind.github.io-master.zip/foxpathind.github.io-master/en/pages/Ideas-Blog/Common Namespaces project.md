# Namespaces #

## Projects ##

### Tasks ###

## 4A's Departments Activity Domains ##

## Activities ##

## General Knowledge ##

## 4A's Knowledge ##

## Persons Categories ##

## Skills ##

## Capabilities ##


# Specific Apps #

## Insightly ##
### Entities
- Projects
- Categories
- Tags
- Contacts
- Organizations
- Tasks
- Events
- Opportunity (?)
- Activity "Type"
- User (multi user project management)
- Team (Groups of users)
- Relationships (is a x of)

[brettterpstra]

### Actions ###

- email into
- tasks notes

## Evernote ##

- Notebooks
- Tags
- Date

