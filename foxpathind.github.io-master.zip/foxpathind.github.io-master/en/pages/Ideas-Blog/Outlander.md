# Outlander

We are still beings of the romantic age as we pull outselves in and out of time/space dimensions through mobile portals, like Superman visiting a virtual Krypton, 



## Modeling and programming the life out of life

Modelling the mind: Intention Genome, Activity streams, intention rank

Need a concept map of the schema and actions of the algorithms


### Products, software

[http://www.fastcolabs.com/3033811/this-could-be-the-last-calendar-app-you-ever-install][1]

[http://mynd.me/#/][2]
[http://www.timeful.com/][3]
[https://www.tempo.ai/][4]


---- 
# Links
[http://s2014.siggraph.org/countdown/][5]

---- 

# Blog post on the internet of things for website
## beginnings
The internet of things is certaining one of the most important topics of the year. Every week seems to bring a new announcement of a new product, new consumer friendly programming languages, new mergers and acquistitions. The helpful, digital inteligence that became first available to people conducting their lives through the PC, then moved to the mobile phone is now moving out into the physical world.

## Programming the internet of everything
Douglas Rushkoff proclaimed, "program or be programmed"[1][6] in a 2010 book[2][7], in 2011 Marc Andreesen[3][8] declared "software is eating the world"[4][9]

http://www.forbes.com/sites/stevedenning/2014/04/11/why-software-is-eating-the-world/
http://online.wsj.com/news/articles/SB10001424053111903480904576512250915629460

Together the argument goes that productive value in today's economy is a function of software or the programmed intelligence of computer systems and networks AND that this reaches down into the individual's daily life - that you can't really live a full life without understanding and being able to craft the software that runs the world today.

 

[1]:	http://www.fastcolabs.com/3033811/this-could-be-the-last-calendar-app-you-ever-install
[2]:	http://mynd.me/#/
[3]:	http://www.timeful.com/
[4]:	https://www.tempo.ai/
[5]:	http://s2014.siggraph.org/countdown/
[6]:	https://www.youtube.com/watch?v=imV3pPIUy1k
[7]:	http://www.rushkoff.com/program-or-be-programmed/
[8]:	http://en.wikipedia.org/wiki/Marc_Andreessen
[9]:	http://news.genius.com/Marc-andreessen-why-software-is-eating-the-world-annotated