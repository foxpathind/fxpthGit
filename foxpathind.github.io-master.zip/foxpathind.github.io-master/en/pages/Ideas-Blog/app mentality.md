## the app mentality and the polaroid camera
### designing experience 
*"using metrics of curation to evaluate information based ideation" acm chi vo. 21 no. 3
* marshall and rogers 1992 on explicit and implicit structure 
	* the timeline organizing life experiences good and bad, 
	* formal structure helps organize
* wilkenfeld and ward 2001
	* free association helps synthesize, form emergent ideas
		* less expected, more remote thoughts

