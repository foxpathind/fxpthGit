##commercial tech becomes personal tech
- how?
- stories
	- itunes
	- iphone
