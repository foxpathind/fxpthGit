# predictive shopping, connected cars, chat bots
an intereting article in the nytimes today reportee on a survey on preeictive shopping that raises some very profound questions for marketers. the results showed that in the abstract a significant number of people would welcome a service that simply fulfilled specific purchases as disparate as books and toilet paper charged them to the persons credit card. interestingly, but obvious, cass sunstein, the researcher also imagined the use of sensors in the home to know when a product was low as a trigger for automatic purchases, and my guess is that people already have accepted and welcome such technology preemptively. most of us have already experienced this in other contexts like hotel room refrigerators 
## bot to bot
## attention out of the equation
## paradox: more time for ads, no need for personal profiling
speak to the bot! 
## brand experience at a distance
marketing moves to the background while product use and word of mouth become even more important. where will this be registered? programming the shopping bot to try a recommended product? use a algorithm that simply places a product on thhentry list when x percent of connections are using a particular brand? what are the likely new consideration list dynamics, package design etc  in a  world where the transaction is no longer primary activity of a human? 
## its still about data

[Cass Sunstein, NY Times 21 Aug - Shopping made psychic][1]

[ connected cars experiments in michigan, honda quoted ][2]

[ 360i blog brands using chat bots ][3]

[1]:	http://www.nytimes.com/2014/08/21/opinion/shopping-made-psychic.html "Cass Sunstein Shopping made Psychic"
[2]:	http://www.nytimes.com/2014/08/21/business/new-era-in-safety-when-cars-talk-to-one-another.html?ref=technology
[3]:	http://blog.360i.com/social-marketing/botornot-are-chat-bots-the-future-of-social-media