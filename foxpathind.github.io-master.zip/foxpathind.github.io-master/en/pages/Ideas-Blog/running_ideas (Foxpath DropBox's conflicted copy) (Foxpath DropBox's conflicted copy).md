# ideas 
* seeds
* stems
* petals
* leaves

#wiki
- issues
	- catalog on the way in
	- boxes
	- operations
	- member tech
	- partners

#cmo summit

## reinventing marketing
- life time customer value vs cpg business
- laura desmond
	- marketing ip based plus stable infrastructure past
	- need a unified view, infrastructure needed for all these data streams  - will take time
	- figure out the way to start - sapient shout out
	- its not the idea, right by data standpoint and "remarkable" the art part, the agecency part
- greg stuart spencer stuart
	- leadership
	- culture 
	- storytell
	- collaborators
- sunil gupta, harvard
- joe tripodi
	- cio cmo
- laura desmond
	- media local and global eso. in digital
	- special skills training
		- project managment
	- certification in media tech
		- **talent loves certification**
- joseph t 
	- need experts
- sunil gupta
	- Harvard cmo of today class 
	- need new cases
	- how to organize
	- where did you get the leadership
- greg welch
	- cmos - 3-5 years now?
	- cmos cant go it alone
	- cmo club
- training new cmos
	- jt: internal search and train
- laura d
	- capability crisis in the new world
	- core competency  crisis, what are firms trying to do.
- ann lewnes
	- global
###Q
- where get these unicorns
	- hire brand manager to cmo
	- data sciencists to brand experts , big picture, need both at once
	- sunil
		- computer science skills taught in many different deppartments
		- 
	- greg
		- divesity of backgrounds 
		- not narrow defined
	- laura desmond
		- many POVs 
- data - over simplifying?
- successful marketer

## ad council
- digital 
- looking into other companies
	- private equity
	- ad tech
- connecting with millenials
- next generation of creatives
- marketing cloud
- 

## michael lewis
-  attention
-  be passionately interested , a sample of one
-  moneyball
	-  not using new data
	-  thinking about data from outside baseball
	-  science experiment, but did the players understand?
	-  a market failure?
		-  the data proved
	- **its not a sport, an industry, everyone is misvalued!**
		- the data improved the market
		- it matters because the players are now so expensive
- flash boys
	- story of reform
	- same reaction
		- people were angry, jobs on the line
	- automation of financial has been beneficial
		- industry clawed back some of the efficiency for profit
		- the little guys are mostly with mutual funds
		- a tax on invested capital
- algorithms replacing people?
	- where does this go in baseball
	- efficiencies yes,  narrow margin, but still only probability
	- whats interesting is what are the limits of algorithmic decision making
		- with people anyway
		- what is the info we dint have that is consequential
	- fighting the quants is hard now
	- smart decisions that end bad are not rewarded
- blindside
	- pygmalion

##adobe and mobile
- responsive design
-  app lifecycle
	-  

