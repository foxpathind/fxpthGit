# ideas 
* seeds
* stems
* petals
* leaves

#wiki
- issues
	- catalog on the way in
	- boxes
	- operations
	- member tech
	- partners

#cmo summit

## reinventing marketing
- life time customer value vs cpg business
- laura desmond
	- marketing ip based plus stable infrastructure past
	- need a unified view, infrastructure needed for all these data streams  - will take time
	- figure out the way to start - sapient shout out
	- its not the idea, right by data standpoint and "remarkable" the art part, the agecency part
- greg stuart spencer stuart
	- leadership
	- culture 
	- storytell
	- collaborators
- sunil gupta, harvard
- joe tripodi
	- cio cmo
- laura desmond
	- media local and global eso. in digital
	- special skills training
		- project managment
	- certification in media tech
		- **talent loves certification**
- joseph t 
	- need experts
- sunil gupta
	- Harvard cmo of today class 
	- need new cases
	- how to organize
	- where did you get the leadership
- greg welch
	- cmos - 3-5 years now?
	- cmos cant go it alone
	- cmo club
- training new cmos
	- jt: internal search and train
- laura d
	- capability crisis in the new world
	- core competency  crisis, what are firms trying to do.
- ann lewnes
	- global
###Q
- where get these unicorns
	- hire brand manager to cmo
	- data sciencists to brand experts , big picture, need both at once
	- sunil
		- computer science skills taught in many different deppartments
		- 
	- greg
		- divesity of backgrounds 
		- not narrow defined
	- laura desmond
		- many POVs 
- data - over simplifying?
	- 

