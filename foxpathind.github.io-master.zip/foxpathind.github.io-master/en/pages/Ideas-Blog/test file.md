# predictive shopping, connected cars, chat bots
an intereting article in the nytimes today reportee on a survey on preeictive shopping that raises some very profound questions for marketers. the results showed that in the abstract a significant number of people would welcome a service that simply fulfilled specific purchases as disparate as books and toilet paper charged them to the persons credit card
## bot to bot
## attention out of the equation
## paradox: more time for ads
## brand experience at a distance
marketing moves to the background while product use and word of mouth become even more important