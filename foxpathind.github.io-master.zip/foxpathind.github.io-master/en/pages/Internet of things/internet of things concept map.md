# concept map
	- algorithms associated with device
		- proprietary
		- open
	- location of functionality/processing
	- schema
	- data
		- produced
		- collected
		- schema
	- connectivity
		- type
		- home
		- public
		- proprietary
	- network
		- home
		- public
		- proprietary
	- address(es)
	- protocols
	- power
	- interoperability
		- machine to machine
		- portals
		- human to machine
		- interfaces
		- visualization
	- interfaces
		- control
		- visualizations
		- reporting
	- programmability and programming
	- primary purpose
	- shared purpose(s)
	- authorities
		- access
		- control

#references
gigaOm
fast company
