#concept map

	- algorithms 
	- data
		- produced
		- collected
	- connectivity
	- address(es)
	- protocols
	- power
	- interoperability
	- interface
	- programmability
# conference thought leadership
	- product road maps
	- state of the art
	- embedded, no interface
	- new capabilities
	- media integration
	- engineering directions
	- middleware
# confernences
	- CTIA
	- structure connect
	- oreilly?
