## Mobile Apps
#### Discussion
- 4A's branded ? Separate app?
- CreateTech?
	- Try out?
		- Bizzabo
		- Sched
- NetForum integration
	- no seamless pass right now
- Cvent - too much trouble
- Mobile app capabilities
	- Excel uplaod
- After the event
- Mobile optimized website
	-  ANA
- Requirements/Desires
	- Conference info
		- Contacts
		- Venues
	- Speakers
		- Bios
	- Sponsors ?? 
		Advertising? - Bizzabo
	- Schedule
		- Personal schedule
		- Add to calendar
	- Social
	- Ger the presentation from the mobile app?
	- Note taking
	- Attendee interaction
	- Reporting
- Approvals
	- AF
	- LB?
	- NH

