Less story more conversation 
Interpersonal 
Big data is not unreal because it is unstructured it is steams of a new potential to understand and to be more in the moment. 
Big data is as real as the weather around us that we try to understand for 
