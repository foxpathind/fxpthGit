# Donald Dea #

## Background - Digital Now ##

- Associations
- 1999 - dot com
- at board ASAE
- forum about to navigate the new digital world 
	- not a trade show
	- Disney
- 250 CEO
	- 35-45% Trade associations
	- 40 - Professional
	- 20 - philantropic
- What keep you up a night?
	- keynotes
	- then workshops, plenary sessions
- Community 

## The Audience ##

- Mostly CEO
- Marketing membership
- 80-100 intervews every year
	- get the messages 
	- value
		- proposition
	- strategy
		- enabling
	- structure
	- 	people process
- talk about 