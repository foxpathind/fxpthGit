#todo Unix
- env paths
- text editing
- moving around the file system
- code folder

#todo python
- extract email addresses by date
