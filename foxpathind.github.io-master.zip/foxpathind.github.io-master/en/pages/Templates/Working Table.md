|Time	| Session Title	| Duration	| People	|  
| ------	| ------	| ------	| ------	|  
|Entry	|entry	|entry	|entry	|  
