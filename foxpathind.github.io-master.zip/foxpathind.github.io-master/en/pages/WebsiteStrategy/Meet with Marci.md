# Website
## Interviews
- Mollie
	- great interview
	- agency life cycle
		- new, mid-life, 
		- agencies changing
		- how can the 4A’s help you manage the challenge
- Tom, Tom & Sal
	- 
- Next week
	- Alison
	- Nancy
	- Jules&Troy
- Following
	- Diversity - Singleton & Carl
	- Research

## VML
- Analytics meeting 
- Monday - 3PM 
- Timeline - Carolyn
	- Share with Marci and Anna

## Taxonomy
- 6-8 weeks Framework
- Then full time resource for tagging
	- Carol?
	- Repository for tagging
		- File system
		- Research - Anna
- Anna - TMG proposal
	- hourly to get both Anna/Atsushi
	- get back to Anna before vacation

# CreateTech
- Ivy Ross - no go
- Add Current speaker to Speakers web page


# Metis
- Talking points
	- evaluation of digital savvy personnel
		- production-related
		- marketing and strategy related
		- future oreiented, proactive
		- specific skills to look for
			- programming
			- design, UX, visualization
			- systems admin
			- databases
			- media ad operations
			- cms
		(more thoughts to come)	
		
- Advisory group proposal for education/training offering

