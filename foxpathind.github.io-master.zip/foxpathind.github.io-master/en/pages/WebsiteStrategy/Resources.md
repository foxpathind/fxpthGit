# Resources

- Staffing
- Ask on the reserve
- another $800K
- 

# Budget numbers
- operationally ongoing
- website
	- marci, web project manager, overlap?
	- 60 - 90 days
	- job spec chick and Marci
	- how to find...
	- contract? 


# KC meeting on the website
	- people must 
	- get VML before board meeting
	-

## next steps meeting

- Features and functions
- 