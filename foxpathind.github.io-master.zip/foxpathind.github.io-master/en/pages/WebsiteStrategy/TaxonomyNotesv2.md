# Taxonomy Project

##October 21, 2014 - 4:10 PM



### Taxonomy intro

### Discussion
- User testing
     - Card sorting
- Types
     - Navigation
     - Faceted search
     - Search
     - MESE
          - Mutualally exclusive
          - Exhaustive
     - Navigation vs Organization
- The 4As perspective not necessarily the outside perspective
     - Not prompted to use a outside perspective
- Taxonomy doesn’t have to be navigation
     - Needs rules
     - No soft rules
     - Relevance
     - Strongly related
- Strategy
     - Audience types
          - Levels
     - Tagging for those audiences
     - Access
          - permissions
          - role
- Conceptual grouping
     - Gap analysis
     - Content life spans
          - creation data
          - check for relevance

- Strategy meeting
     - Strategy
     - Content strategy


##CF Notes
- Taggers needs
- Conceptual groupings
     - Themes
     - Subjects
     

## Walkthrough
- What would be human-applied by the tagger
- Audiences
- Regional
     - International
          - non-US
          - (probably need world regions)
     - Councils
- Agency Lifecycle
- Content types
     - mobile ready?



October 20, 2014 - 5:35 PM
## Staff on the taxonomy
- Look at staff
- Keep Marci through March



=======
# Taxonomy Project ##





# October 16, 2014 - 4:10 PM
- Some concepts (working)
	- audiences
    - subjects, topics, issues, POVs
    - regions
    - document types
    - 4As departments
    - 
## Anna's Tour
- Note: Audiences
	- scrapped the constituents
    	- not useful for use case
- General Subjects
	- Membership information
    	Benefits
        Joining (Use) - life cycle
    - 4A's Communities
    - Vertical industries - research industry pages
    	- Check with Marsha
    - Target Audiences (of advertising)
    	- B2B
        - Consumer categories
        	- Demographics
 - Agency Compensation
 	- what are you charging for?
    	- Agency Services - as sold
    	- Agency Roles - Teams
    	- Activities
    		- negotiation
        	- pricing
            	- methodologies        
    - parts of relationship
    	- MSA
        - Rate Card
        	- Salaries
        - Scope of work
        - Contract
        - NDA
        - Owners
- Duplicate terms
	- equivalence

- Agency evaluation
>>>>>>> FETCH_HEAD

- 
     
            
    
    

# October 9, 2014 - 3:11 PM
## Checking With Wordpress Vendors ##

- Taxonomy pilot project
- Content management
	- Repository
- Alley Interactive
	- Great idea
	- Low 5 figures - under $50K ?
	- Would go into the development project
	- Project looks 
		- Skeleton migration step - of website 
		- Or do all content
		- save a reference to original location
		- create a taxonomy tool
		- to develop as a "plug-in"
		- then tag the the migrated content
		- We could start looking at what this will look like
		- Create pilot pages
			- (Need to list all the skills and management necessary)
			- (What does the project look like now)
	- Document management
		- File system? possible?
		- Sharepoint? we would need to upgrade in order to make the investment worthwhile
		- What is the status now
			- Files?
			- Sharepoint?
			- netForum?
- What is the state of the taxonomy?
	- Need an update? on
		- Subjects
		- Audiences
		- Regions
		- Content types
- Get VML involved - get on the calendar
- Create a list of questions

### Next Steps ###

- Taxonomy review
- VML conversation







###Taxonomy  ###

Content type example

- Canonical term
- Notes
- Synonyms
- 

HBR - 
their redesign is going through is reducing 1200 terms to 200



### Activities


- exercise
- existing
- analysis
- interim
- strategy
	- will the impact the interim state of a taxonomy

#### Tools ####

- manage terms 
- useful for the implementation
- 