# 4A's/VML Account management
- Marnie Levine mlevine@vml.com
- Billing will start on a monthly basis
- Full scope 135K
	- 55,213 Actual to date
- Actuals to date
	- We are on schedule 
- Invoices - email or delivered on paper
	- Who to send it to



