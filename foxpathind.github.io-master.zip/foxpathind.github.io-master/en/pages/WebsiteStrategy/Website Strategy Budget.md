## 1st quarter 2015

- Hard number 
- Taxonomy
	- Anna billing hourly
	- 2500, 3000 month
	- VML taxonomists
	- Getting feedback
	- Process
		- Fnalize the Taxonomy
		- Going the content
			- Codifify in a spreadsheet?
			- Audit content with columns of data
	- Hire taxonomist for guidance and project structure
	OR
	- Audit of all content
	- Marci tee up the "content location project"

- CMS audit
- Strategy done
- Taxonomy
- January ask for next fiscal
- Doable
- 