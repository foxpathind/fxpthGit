## Notes

### xchange meeting
- Part of tpur strategy is a better website - reach more people, **emulate the member visit**

### Taxonomy meeting
-  Really want to browse to investigate a topic
- Versus find a particular piece of contact 
