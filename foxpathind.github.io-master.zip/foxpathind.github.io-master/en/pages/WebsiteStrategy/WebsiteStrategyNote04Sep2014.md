Internal | Coordinator | When | Status
---------|--------|--------|----------
Diversity | ???? |?????|?????


Agency | Coordinator | When | Status
---------|--------|--------|----------
MgB | ???? | Week of 9/15 | Scheduled
Sapient | ???? | Try for same week | To do
BSSP | ???? | ????? | ??????
VML KC | ????? | ????? | ?????

Timeline will then be updated

4A's events are now in the timeline

Survey can be drawn up after the first agency interview
Survey Date 9/22
Need a marketing plan for the survey

ToDo post to Redbooth Nudge to MgB

Andy may be doing the interviews for Tarini who is not feeling well

*Where is the schedule of the interviews*

####Are you getting what you need?
	* Hearing contradictions
	* Marketing Plan next week

####Content/site audit

	* Monday kicking off
	* VML will deliver quick description
	* Will need to add a sense of the content that will be coming
		* meet with Alison or team
	* Functionality audit??
		* We look at from a usability heuristic and gap analysis
		* It's related only to the use point of view
		* Technology track ?
		* When scheduled, part of requirements prioritization
	* Webmaster/Editor user functionality?? - 4A's responsibility


####SEO

	* What are people looking for
	* What terms can be incorporated in the site

#### Wordpress/Drupal ####

	* eMedia meeting with VML about the CMS discovery project?
	* developers that are conversant with platforms
	* VMLs perspective 
	* 4As will be keeping 






	
