November 18, 2014 - 10:06 AM
# Recap

##Inputs

#Intro

##Statement
- the vision
        - the business partner
- 4As' eco system
        - not unified
        - need to include the council sites
- Where going today? - Main site
        - bounce rate?
        - managment matters, research atters
        - Events
        - Agency Search
        - don't know
- Conclusions
        - 8,500 user accounts - many untapped
- Priorities
    - Business goals
            - Indispensable resources
            - Build relationships
            - Recruit and retain
        - Marketing Goals
            - Bridge gap medai and creative
            - Exposure
            - Millenials
            - Transforamtion
        - Goals
            - Grow active user base
            - Personalized
            - Millenials
            - "Dynamic" content creation
            - Industry thought leader

##  Grow active user base
- get users to use and read the site
- Learnings
    - bring in
    - profiles
    - for everyone
* How?
    - Encourage Account creation
    - Gated content
    - Tracking individuals
    - on-boarding content
    - Personalized experiences
        + Role based
            * manage content prefs
            * tag to personalize dimensions
            * Track for personaliz
            * Role and interest based content
        + Relationship owners and managers
            * automate process giving access to managers

## Millenials
- Easily lost audience
- No phones
- App
- How?
    + Automate permissions (?) 
    + Discoverable - taxonomy
    + Shareable - (permissions?)
    + Integrate social etc
    + App - primary touch point - core function ality
- Manaul vs Automation
    + Live chat function - escalation
        * _Getsatisfaction_
        * etc 
    + Requests
        * Track off line requests
        * Web based forms 
            - _Uservoice_

## Dynamic content recreation
- Site templates and forms for easy creations and auto tagging
    + Region, roles etc
- Repurpose and reformat content
- More than one format

## Thought leader
- Searchable
- Working with outside thought leaders
- Users aren't brand loyal
    + Opportunity!
- How?
    - User centric tagging - folksonomy
    - SEO
    - Curating from outside industry
    - Experts on specific topics
    - Voice on the site, community
    - co-created native ???
    - App - make top of mind

## Rethinking the Ecosystem
- consistent branding
- integrate push content integrated into main site
- Questions
    + Seamless logged in state?
    + Extend personalization
- _CF - Imagine the the use cases, time on site etc. examples of other site_
- Connect the dots
    - blog
    - events
    - aaaa.org/
    - MAIP
- Omnichannel ?
    - today a multi channel
    - create a omni channel experience
        - more seamless
        - profile management
        - track users
        - Crowdtwist - opt-in analytics
            + Facebook, site, instagram
- CRM
    + Emails 
        + limited to one to two emails a day
        + except events
        + integrated all content
        + add interests in the personal emails
    + Social
        * Versioning for social, multiplication
        * Curate other thought leaders and UGC
        * Industry visible cahracters

## Mobile App
- Shifting to mobile
- the computer of today

### Mobile workstreams
- content foundation
    + Clean up content for mobile
- responsive 
    + website is the front end
- wearables??
- native apps
    + need to consider and learn
- Mobile Web
    + Website needs to be mobile friendly
    + move away from m. website
    + it's the same site!
- Mobile first
    + always start the conversation not necessarily the most important
    + usually will work on desktop
- Complement App and website
- App
    + important but higher risk
    + behavior is shifting to apps
    + task based - major brand unbundlings (Facebook)
    + Align to business goals
        * Millenials: mobile and apps
    + Push message
        * Notification center
- _CF - Continual delivery strategy_
- Prototype thoughts
    + Personalized news
    + sign up for events
    + user profile management
    + iterate
- App challenges
    + Cost
    + Gain users
    + Adoption
    + Get partners to adopt
        * Agencies
    + Start
        * iOS
        * NYC
        * Measure
        * etc..
- _CF personas and scenarios_

## Analytics
- What should we measure?
    + Surveys
    + Behaviors
    + Outcomes
- What we will we learn?
    + Surveys
    + Behaviors
    + Outcomes
- KPIs list
- Dashboard
    + Member and non-member dashboard
- _Require data governance, campaign management etc etc._
- HOW?
    + Survey
    + URLs and SEO
    + segmanetation tags
    + IP filters to see what agencies
    + GA "Views"
    + Dashboards for Google APIs
    + Quantify Agency utilization
    + Try to find the pain points
        * _CF Business value_
    + Report also to members!!

## SEO
- 4A's authority ?
    + measure the influence of the site
    + inbound linking doamins and social shares
    + leverage the main domain for the higher authority
    + domain authority? 0-100
        * 72 is very solid but depends on the industry
        * comparative, needs to get the competitors
        * 100 - Wikipedia, google
- Content
    + on-page factors
        * **Titles**, **meta descriptions**, **H1 tags**, **alt image tags**
    + content quality
        * sufficient, in-depth, duplicates, crawlable
        * micro formats 
- Technical elements
    + navigation
        * text links, breadcrumbs, url structure, 
    + Technical
        * XML site map, 404 page, 302 pages, social sharing
- Key takeaways
    + Low quality pages
    + Redirecting

## What's Achieveable
- Light, medium and heavy


## Content Strategy

- Types of content
    + user centric
    + daily vital resource
    + deliver thought leaders
- Access the content
    - bring more front of firewall
    - mobile first
- Digesting content

### Framework

- Customer facing content
    - Standards
        - Formats
        - Relevance
        - Thought leadership
        - Engagement
    - New brand positioning
    - Online community
        + optimize off line communities?
        + 
    