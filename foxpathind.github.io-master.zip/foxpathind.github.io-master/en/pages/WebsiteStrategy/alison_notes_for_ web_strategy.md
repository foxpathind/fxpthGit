## website notes

- promises to agencies
	- Ad of day
	- Profiles agency of week	

- location geo region
	- give me my region
	- give me my interests
	- manage my profile
	- help me use the site
- members voice
- about and by our members

## case study -  ourselves


