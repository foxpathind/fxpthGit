## Web strategy and ongoing We

### Web meetings

- Resume weekly meetings
- Add Liz
	- Become 
- Jules will go back to digital content
	- Media partnerships not
- List of web tasks
	- Google anlaytics
	- Redirect loop - Safari shopping cart
		- Not necessarily triggering a support
	- What's going on backlog and technical debt
- Joe needs more time for taxonomy and web strategy
	- Rough draft 
	- Get 
	
		