## content strategy

- content gaps
- taxonomy
- frequency - fresh daily
- editorial calendar
- content multipliers 
- _cf - get the leadership on board_
- _should the content been Alison and team only_
- content media types
-  roles 
	-  digital copy writer
- summary
- delivery, goverance roles 
	- what the site is being designed for


