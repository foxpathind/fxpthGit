```
CreateTech Is All About Imagination
 
Imagine the emerging world of connected people, places and things with thought-provoking technologists, artists, engineers, scientists, designers and programmers, managers and communicators.

There'll be sessions on civic interaction design, advanced agency creative technology management, dramatic brand experiences, biohacking and connection science, and much, much more.

``` 


```
Imagination and the made world

with the digital we don't leave the made world behind

the anxiety when the made world takes on agency

motion at a distance

decision makign at a distance

distributed and shared, too much for one mind to control

we are sharing the world 

it is still up to us and our imaginations to see through our own creations and behaviors and work the contexts environments and levers of the connected world

to understand the levers of the connected world

where our feelings and needs have determined the shape and actions of these things 

and now with their own dynamics and power their own actions and behaviors we lose a clear sense of the distinctions

but still have the power to understand our selves and where we are likely to be headed and what concepts and tools we'll need to live into 

ImaginTion to understand the world that is coming into being and how we want to construct experiences in that world 

Not just goal determined entertainment or storytelling.

Imagination to see the possiblities

To widen our view of how the world is made and what constitutes value experience and engagement worth our time.
```

Imagination to understand the world that is coming into being and how we want to construct experiences in that world 

Not just goal determined entertainment or storytelling.
Imagination to see the possiblities

To widen our view of how the world is made and what constitutes value experience and engagement worth our time.


