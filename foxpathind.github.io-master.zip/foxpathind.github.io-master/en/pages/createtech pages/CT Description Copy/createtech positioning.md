# what is the future of advertising? 
## you won't get the answer at 4A's CreateTech. 
### what you **will** get is breakthrough perspectives 

- From  thinkers exploring the multiplying nodes and edges of our connected age, 
- From the creative technologists embracing complexity, 
- From the masters of experience design crafting meaning in our digital lives.


----

hear about ideas from broad range of thinkers.
hear about new solutions to to old and new problems needs from a wide array of creators
from creative technology leaders from many fields. 

## we cant do everything in two days but we know **you're up to it**. 

----

Your smart phone is more powerful than the comouter that took humans into space. 

Will the user will soon be able to over power the most sophisticated targeting platforms on the planet? 

What will marketing look like when the whole world around you is digitally alive, 

How to communicate in a data rich context that responds to people's slightest intentions? 


The answers will be created by you! 

Meet your peers,  the new generation of advertising professional, 
the collaborative digitally enabled thinkers and makers at 4A's CreateTech

4As - createtech: no edges, no answers but pushing your ideas further
 
**"You know who you are!"**
