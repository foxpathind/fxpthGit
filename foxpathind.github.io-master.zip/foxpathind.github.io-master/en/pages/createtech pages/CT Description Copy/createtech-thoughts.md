ImaginTion to understand the world that is coming into being and how we want to construct experiences in that world 
Not just goal determined entertainment or storytelling.
Imagination to see the possiblities
To widen our view of how the world is made and what constitutes value experience and engagement worth our time.
