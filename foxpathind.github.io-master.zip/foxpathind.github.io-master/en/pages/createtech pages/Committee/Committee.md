###4A's Creative Technology committee:


* Alan Schulman, VP Global Digital Marketing & Brand Content, SapientNitro
* Tim Leake, SVP / Growth & Innovation, RPA
* David Reeves, SVP, Creative Innovation and Development, 22squared
* Jason Alan Snyder, Director of Technology, North America, Momentum World Wide
* Tanya LeSieur, Chief Production Officer, Saatchi&Saatchi
* Mark Avnet, Dean, 360iU, 360i
* Sermad Buni , Senior Creative Technologist, BBDO
* Rick Gardinier, SVP, Chief Digital Officer, Brunner
* Andre Alguero, VP, Technology, Digitas
* Dan Fox, VP / Executive Creative Technology Director , Crispin Porter + Bogusky
* Craig Elimeliah, SVP, Director of Creative Technology, RAPP
* Chuck Philips, CTO, Digitaria
* Raghu Kakarala, Chief Technology Officer, Engauge and WE Engauge
* Mathew Ray, SVP, Director of Creative Technology, Mullen
* Angela Fung, Senior Partner, Executive Director of Digital Production, Ogilvy & Mather
* Michael Phillips, Director, Digital & Creative Technology, Eleven
* Charles Duncan, Director of Technology - VML New York
* John Running, EVP, Director of Innovation and Technology, Hill Holliday
* Conor Brady , Executive Creative Director, Critical Mass New York
* Keith Johnston, COO & CTO, T3
* Brian Barthelt, SVP, Director of Digital Delivery, Arc Worldwide
* Scott Prindle, Partner/Chief Digital Officer, Made Movement
* Kurt Roberts, Director of Creative Technology, RP3 Agency
* Mark Logan, SVP, Digital Innovation, Barkley
* Gela Fridman,VP, Technology, Huge
* Robert Christ, Tech Director, The Barbarian Group
* Michael DiGiovanni, Emerging Technology Lead, Roundarch Isobar
* Trevor O'Brien, Partner, Technologist, The Experiment




###4A's Creative Technology committee:


* Alan Schulman, VP Global Digital Marketing & Brand Content, SapientNitro
* Tim Leake, SVP / Growth & Innovation, RPA
* David Reeves, SVP, Creative Innovation and Development, 22squared
* Jason Alan Snyder, Director of Technology, North America, Momentum World Wide
* Tanya LeSieur, Chief Production Officer, Saatchi&Saatchi
* Mark Avnet, Dean, 360iU, 360i
* Sermad Buni , Senior Creative Technologist, BBDO
* Rick Gardinier, SVP, Chief Digital Officer, Brunner
* Andre Alguero, VP, Technology, Digitas
* Dan Fox, VP / Executive Creative Technology Director , Crispin Porter + Bogusky
* Craig Elimeliah, SVP, Director of Creative Technology, RAPP
* Chuck Philips, CTO, Digitaria
* Raghu Kakarala, Chief Technology Officer, Engauge and WE Engauge
* Mathew Ray, SVP, Director of Creative Technology, Mullen
* Angela Fung, Senior Partner, Executive Director of Digital Production, Ogilvy & Mather
* Kip Voytek, CEO, RumbleFox
* Michael Phillips, Director, Digital & Creative Technology, Eleven
* Charles Duncan, Director of Technology, VML New York
* John Running, EVP, Director of Innovation and Technology, Hill Holliday
* Conor Brady , Executive Creative Director, Critical Mass New York
* Keith Johnston, COO & CTO, T3
* Brian Barthelt, SVP, Director of Digital Delivery, Arc Worldwide
* Kurt Roberts, Director of Creative Technology, RP3 Agency
* Mark Logan, SVP, Digital Innovation, Barkley
* Gela Fridman,VP, Technology, Huge
* Robert Christ, Tech Director, The Barbarian Group
* Michael DiGiovanni, Emerging Technology Lead, Roundarch Isobar
* Scott Prindle, Partner/Chief Digital Officer, Made Movement (Founding Chair)
* Trevor O'Brien, Partner, Technologist, The Experiment (Founding Chair)