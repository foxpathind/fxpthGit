
The Future of Advertising is…

A) Connecting all the multiplying nodes and edges of our networked society
B) Embracing complexity through creative technologies
C) Crafting meaning in our digital lives through experience design
D) All of the above
E) None of the above
F) Blah blah blah


Here’s the answer: the future of advertising is what we will create together, today and tomorrow. It will come from a broad range of thinkers and creators building solutions to new and old problems. It will emerge on evolving technology platforms, with leadership from many fields.

CreateTech 2014 brings together those thinkers, creators, and leaders for substantive conversation and inspiration on the most important creative issues of the moment.
	•	What happens when users can overpower the most sophisticated targeting platforms on the planet?
	•	What will marketing look like when the entire world is digitally alive?
	•	How do we communicate in a data-rich context that responds to people’s slightest intention? 
	•	How do we create in a world with no boundaries, no edges?


There are no answers
Because the answers will be created by you.

The answers will be created by you and the new generation of advertising professionals at 4A’s CreateTech.

Meet the new generation of advertising professionals—thinkers, makers, peers—at 4A’s CreateTech.



Find out where advertising’s future will be
Plot the course of advertising’s future
Envision the future of advertising










