
Blaze the Trail

The path to advertising’s future is emerging now—today and tomorrow—from thinkers, creators and leaders in many fields. 

Hear from Fairhaven Capital, Harvard Innovation Lab, MIT, Micrososft Research, city of Boston's New Urban Mechanics. Innoccean, DeutschLA, SapintNitro. Inventors from outside and inside advertising. 

Technology has changed everything. Where will it take us?

At CreateTech 2014—Boston, November 12-13, join tech innovators, industry leaders, and your peers in creating the future. 

[Names and pictures]


Help blaze the trail.
Contact and registration info.
