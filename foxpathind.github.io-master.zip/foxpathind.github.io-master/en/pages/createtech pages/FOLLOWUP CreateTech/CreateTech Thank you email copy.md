Ben and Drew,

I just wanted to thank you both once again for a fascinating presentation at CreateTech. 
The event this year was particularly good and due completely to great contributions like yours. 
I really appreciate the creative intelligence that went into the project and all the attention that went into making a great presentation.

I hope we will be able to work together again!

Chick 