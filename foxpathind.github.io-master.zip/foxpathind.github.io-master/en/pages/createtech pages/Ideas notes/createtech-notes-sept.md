divergent thinking (guilfoed 1957, buxton 2007)
"assembles many corrct and relevant answers" 
acm transactions chi 2014 vol 21 no. 3

dedicated to divergent thinking 
