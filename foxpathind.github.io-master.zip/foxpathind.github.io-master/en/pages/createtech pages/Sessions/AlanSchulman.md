## Alan Schulman ##

- Sapient
	- CMO and CTO not the right audience
- Did a deal with MIXX conference with Kimberly Clark
- Was going to deliver MasterCard
- Sheldon even more provocative
	- Talk about how the role and title 
	- John Cain - internet of things analytics
- Sheldon - evolution of the creative technologists 
- Heads up ASAP
- 