## Andrew Mason - Macaw ##


- finding partners
- professional tools for developers/designers
	- compete with Adobe
	- tools that do more
- spoken at conferences
- partners with General Assembly
- cash sponsorsips not so much
- cross promotion and rev share
- we are leading the market
	- our audience is engaged
- dedicated discount for members, giveaway
- promotion 
- seminar on creative tools
	- do something unique