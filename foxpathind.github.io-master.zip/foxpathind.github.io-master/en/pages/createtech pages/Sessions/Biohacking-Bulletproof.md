## Bulletproof Coffee ##

* Sleep hacking
* 15yrs experience

###Dave Asprey
Founder and CEO of The Bulletproof Executive, 

Dave Asprey, The Bulletproof ExecutiveDave Asprey, founder of The Bulletproof Executive, is a Silicon Valley investor and technology entrepreneur who spent 15 years and over $300,000 to hack his own biology. Dave lost 100 pounds without counting calories or excessive exercise, used techniques to upgrade his brain by more than 20 IQ points, and lowered his biological age while learning to sleep more efficiently in less time. Learning to do these seemingly impossible things transformed him into a better entrepreneur, a better husband, and a better father.

From private brain EEG facilities hidden in a Canadian forest to remote monasteries in Tibet, from Silicon Valley to the Andes, Dave used hacking techniques and tried everything on himself, obsessively focused on discovering the answers to this one persistent question:
What are the simplest things you can do to be better at everything?

What emerged is the idea of being “Bulletproof”, the state of high performance where you take control of and improve your biochemistry, your body, and your mind so they work in unison, helping you execute at levels far beyond what you’d expect, without burning out, getting sick, or allowing stress to control your decisions. It used to take a lifetime to radically rewire the human body and mind this way, if you were lucky enough to even know it was possible. Technology has changed the rules.

Dave founded The Bulletproof Executive to make these breakthroughs – and the body and brain you deserve — easily available to you in your everyday life.