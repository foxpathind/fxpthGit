## Byron Ellis ##


CTO of Spongecell, where he heads research and development. Prior to Spongecell, Byron served as Chief Data Scientist for LivePerson, a company that helps businesses engage in real-time customer communications. 

Byron also held various leadership positions at AdBrite, eventually serving as the company’s CTO. Byron holds a PhD in Statistics from Harvard University and was a postdoctoral fellow at Stanford Medical School. Byron earned a BS in Cybernetics from UCLA.

https://www.youtube.com/watch?v=HgMU5rFiz7g

https://www.youtube.com/watch?v=DRgs8L4AOgc

https://www.youtube.com/watch?v=gomIN0BmZRo

Let me know if I can do anything else—connect you with Byron, put together a formal submission, etc.  Thanks!