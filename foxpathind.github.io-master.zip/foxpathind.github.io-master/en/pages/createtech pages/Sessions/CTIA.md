#CTIA
##[SuperMobilityWeek]()
1. Wireless life sciences
* Autos
* Home
* IoT -> M2M - largest exhibit in the world
* Super Mobility Week


Content Tracks
1. Enterprise
2. Leading Edge 

  3.Connected Life

  4. Intelligent Network - hardware to software

  5. build something around marketing and advertising
  6. 
    1. Need to organize into one area
    2. Created custom agenda for Shelly Agenda

[http://supermobilityweek.com]
