# CTIA ##

Jackie

- Mobile and regulated industries
	- Healthcare
	- Transportaton
	- Financial services
- Policy issues
- Outreach 

## Connected Life Segment ##

- Common issues
- Migration to connectivity of the environment
- _Opportunities_
- _Challenges_
	- Privacy
	- Data management
- Content partners
	- Specific issues
	- _New players not traditional players_

## Jackie ##

- Content partners



## Super Mobility Week ##

CTIA, Super Mobility Week is North America's largest forum for mobile innovation and the most influential mobile marketplace that brings together the leading authorities on the connected life.
