On Tue, Aug 26, 2014 at 9:18 AM, Milli Carr <Milli.Carr@digennaro-usa.com> wrote:


##DDB
Hope you’re well. You were previously in touch with my colleague, Dejon Mullings (no longer at DGC), about DDB potentially participating in the upcoming CreateTech conference. We’re currently working through a few session ideas and wanted to make sure you were still accepting proposals, and if so, if there was a particular format you’re looking to fill?
 
While we don’t have anything formal to present to you yet, we are hoping to develop 

- a session with McDonalds that would highlight how the megabrand activates on new platforms, like Instagram and Spotify, as well as its own in-store WiFi network, considered ahead of the curve. Since McDonalds was one of the first paid sponsors of Instagram/Spotify, they have a wealth of data, insights, etc that could be shared with your audience in a very visual and interactive session.

Can you let us know where you are in terms of programming so that we can plan our submission accordingly? Once we have more concrete details on the above, we’d love to arrange a call to go over our session idea in more detail.
 
Look forward to hearing from you!
 
Can you let us know where you are in terms of programming so that we can plan our submission accordingly? Once we have more concrete details on the above, we’d love to arrange a call to go over our session idea in more detail.
 
Look forward to hearing from you!
 
Thanks,
Milli