As we take a look at the increasing ubiquity of intelligent data gathering and realtime contextual analysis, where should we begin to look for how to design brand experiences? Should they become more service oriented versus message oriented?  What can the fields of user-centered product and service design learn from tech marketers about how to craft holistic brand experience strategies to deepen connections?

Mike Baker the CEO of DataXu and I are putting together a panel of thought leaders to talk  about rich data, from the web and devices, but also now the internet of things, environments, etc and the creative challenges of experience design, dynamic creative etc. that this new world makes possible.

As we take a look at the increasing ubiquity of intelligent data gathering and realtime contextual analysis, where should we begin to look for how to design brand experiences. Should they become more service oriented versus message oriented? What can the fields of user-centered product and service design tech marketers about how to craft holistic brand experience strategies to deepen connections?


Vlad
Monotype
SpongeCell
Boston Creative 

