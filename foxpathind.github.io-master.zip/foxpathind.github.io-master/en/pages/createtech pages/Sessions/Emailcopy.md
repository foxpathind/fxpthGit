## Email copy 18 Sep 2014

Connections

Physical, Digital, Biological

Sensors, data, motivation

David Shrier, managing director of Connection Science & Engineering, MIT
Jason Levy, SaatchiWellness
Mike Baker, CEO of Dataxu

are among the great speakers at CreateTech 2014 covering the intelligent networks connecting life and world today. And devining the emerging opportuntites for creative expressiveness and relevant impactful communications 

4As CreateTech

Be there!