## Kati London 07Oct2014 ##

October 8, 2014 - 2:24 PM

- What can
- Sentient data server
	- mechanicalls - like
	- any kind of character
	- generates and reactions and emotions
	- prototype for 311 data
		- create a personality
		- neighborhood cartoon 
	- ITP
		- self aware bikes
- Experiments
	- Ethical
- Cortana - Siri
	- Demo
- Powerpoint and a video
- Inviting a colleague
- Talk title
- Talk description
- Katie 