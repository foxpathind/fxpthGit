Hi Keith,

Mike had suggested Greg but I hadn’t spoken to him yet. The idea was to talk about data, analytics and data-driven creative. The primary goal was to get people thinking more about the creative design and technology solutions needed to fulfill against the rich contextual and profile data and analytics now available. Mike thought Greg might be a good counterpart, representing the creative side, in that discussion but we hadn’t settled on that. 

I’d like to include perhaps another data/ad tech firm and a very data-savvy creative. Still needs work but Mike is a very smart guy and I’m happy to have him present his thinking.

I don’t really know anything about the work at BSSP (though I always meant to find out!) but I can imagine that is a good storytoo. And we haven’t worked out yet what the panel or conversation with Mike is going to look like.

We are also hoping to have lightening rounds (5 minutes) for agencies to present “work from the lab” as this has become a bigger and more successful part of agency life.

The commitments and various proposals are just firming up now and with that I’m able to finally visualize the timings and schedule better. I’m going on vacation next week and right after labor day I should have an idea about where things are. I’d like to hear more about your panel idea (would you want other agencies to discuss with?) or some other involvement. 
