## Open proposals

### MEMI
Here’s the background on MEMI:

About MEMI:
- wearable technology disguised as fashion jewelry
- two female founders (HBS and Wharton)
- design patent + provisional utility patent filed  
- successful $100K Kickstarter campaign (2013) 
- techcrunch pitch-off winners (2014)
- HBS new venture competition regional finalists (2014)

The challenge:
Getting into production will cost $500K which covers tooling, certifications, production, shipping, payroll, pr/marketing, among other things.


MEMI features:

-classic, silver bangle 
-has no screen and makes no noise
-iPhone compatible, adding Android in 2015
-three distinct vibration patterns (calls, texts, calendar alerts)
-rechargeable via micro-USB hidden within its clasp
-battery life up to 5 days, depending on number of calls and text received
-one size fits most


Press Highlights:
New York Times
Forbes
FastCompany
Mashable
TechCrunch
Refinery29
Fashionista

Cheers!
Amanda
Amanda Neville
Three Furies Consulting
347.489.5341

To stay in touch, find me on LinkedIn and follow me @furiouslymandy! 
