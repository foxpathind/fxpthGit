## Mike Baker Conversation

- Ray Velez
- Greg Stern
- Jim Edwards ??
- John Dain , Sapient
- Bryon Ellis, CTO SpongeCell
- Visionary Creative, spark& honey

Intros with slides
Graphically rich. 

Mike is in NYC

Ray
around commerce

Byron
adtech - ad unit rather than a static, render through data, why hasn't it taken off more? burdensome. HTML 5 what way to automate, programmatic creative, been around why not relevant?

Sapient
digitizing stores, customer experience, point of sale what happens, or more broad, Amazon etc redefining cust EX, service design
integrate online and offline

Can you lever that up?
No, but hy is that?
why doesn't that 

Mike Baker - moderator - integration
BSSP forced to more integrated to outpunch their weight - lurching to find the capability, questing. How do we put it together. Bring back the pragmatic aspect, how do I win new business. Talk about BSSP determine relevance by context.  

As we take a look at the increasing ubiquity of intelligent data gathering and realtime contextual analysis, where should we begin to look for how to design brand experiences. Should they become more service oriented versus message oriented. What can the fields of user-centered product and service design tech marketers about how to craft holistic brand experience strategies to deepen connections.

----
Mike Baker the CEO of DataXu and I are putting together a panel of thought leaders to talk  about rich data, from the web and devices, but also now the internet of things, environments, etc and the creative challenges of experience design, dynamic creative etc. that this new world makes possible.

As we take a look at the increasing ubiquity of intelligent data gathering and realtime contextual analysis, where should we begin to look for how to design brand experiences. Should they become more service oriented versus message oriented? What can the fields of user-centered product and service design tech marketers about how to craft holistic brand experience strategies to deepen connections?

Below you’ll find the description of the conference as well to put this panel in context. We’re drawing on thought leaders from many fields and our hope is to surface how our industry will take it’s place in this innovative age.

The media firms can out buy th edeign only firms

----

[Media, design, consulting, IT/DevOPs]


## Theme
>
wide-ranging discussion about rich data, from the web and devices but also now  the internet of things, environments, etc and the creative challenges of experience design, dynamic creative etc. that this new world makes possible.


That sounds great!  I know Byron is keenly interested in wearable tech, in particular.  Plus—and this is just spit-balling here—I think there’s something to be said about how creatives should be thinking about (and, ultimately, harnessing) the plethora of user data the Internet of everything is going to create.  I’ve seen a few people in the space talking about it—Amy Gershkoff, Mark Himmelsbach et al.—but think it’s an undertold story.  

Anyhoo—here’s Byron’s bio and a few speaking clips I pulled from YouTube, in case you’re interested.  

Byron Ellis is CTO of Spongecell, where he heads research and development. Prior to Spongecell, Byron served as Chief Data Scientist for LivePerson, a company that helps businesses engage in real-time customer communications. Byron also held various leadership positions at AdBrite, eventually serving as the company’s CTO. Byron holds a PhD in Statistics from Harvard University and was a postdoctoral fellow at Stanford Medical School. Byron earned a BS in Cybernetics from UCLA.

https://www.youtube.com/watch?v=HgMU5rFiz7g
https://www.youtube.com/watch?v=DRgs8L4AOgc
https://www.youtube.com/watch?v=gomIN0BmZRo

Let me know if I can do anything else—connect you with Byron, put together a formal submission, etc.  Thanks!


----
October 29, 2014 - 2:04 PM


Vlad Monotype - core tech, digital media, W3C - tech strategist
Bryon Ellis - ad tech, dynamic creative, data signals into ad domain, personalization as well as interactive features, airlines, snow pack, big data guy. Science
Katy at DataXu
John Cain - MIA
Mike Baker - programmatic buying platform, looks at 30 lots a data, context brand specific algorithms - drive marketing ROI

The panel- talking to the creatives
Writing a final precis
Connected age - different environement, customer experience, mobile instantiates the customer experience, data poor to data overload, media scarcity over abundant
initial - the creative layer is it keeping up? what are the possibilities.
what's real today - what is dynamic creative today
what people are willing to pay

- the consumers environment
- the technical challenge and the creative assets challenges
- 

## Questions
- What data is available?
- what tools and platforms are available and coming?
- management and workflow
- automated creative what does that look like
- everything as a service, on-demand, primitive services elements
- just in time utility
- design creative primitives for speed of life
	- sponge cell features, attached or not attached to data
- development lifecycle
- mass scale new scale - QA the creative at the individual dynamic level
	- sampling of QA
	- analytics, not provable bottom
	- census bases approved
- @vlad - ability the set of tools is what is given to them
	- what's possible on creative side are limited
	- preserve brand identity - which elements? - downloadable fonts
	- personalization across the connected experience
		- not accessible to creatives
- showing some visuals but put into - a presentation
	- katy - wil gather
	- show you what I mean?
- summarize talking points 

