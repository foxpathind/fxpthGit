## Monotype ##

- Corporate comms director at Monotype
- digital advertising that Amy from Montotype
	- digital and traditional agencies help with the pain points
	- Amy Alwards
- HTML 5 
- Amy
	- HTML 5 is driving this, responsive
	- Respond in real time
	- opportunity context 
- Monotype
	- Typecast - model ads  - Tom Keever
		- 
	- Responsive design