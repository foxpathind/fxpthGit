## Powell Communications
	Jaime Levitt
	Powell Communications
	84 Wooster Street, Suite 604
	New York, NY 10012
	jlevitt@powellny.com 
	O: 212-475-6301 x116
	M: 202-288-4339



## For follow up discussion:

- M. Leibowitz - Current presentation overall technology through the pieces of the agency. ML to review theme etc.
- KBS+/Spies and Assassins - Mike Dorie, Matt Powell - agency: the value of  software/hardware development and quality. 
	- OReilly topics
	- Short abstract
- Innoccean neuroscience and commercials
	- SXSW - Brand love 
- Possible opportunities: Innovation lab panel, agency createtech lightening rounds, agency/client presentation (Innovation, creativity, collaboration presented through case study with a client)