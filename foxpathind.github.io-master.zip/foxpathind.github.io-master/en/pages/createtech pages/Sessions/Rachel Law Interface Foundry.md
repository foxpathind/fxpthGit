## Rachel and JR ##

- Floor plans
- 1 hour to set up
- iBeacons run on the own
- style guide that they could pull
- workshop - how to make data bubbles
- $8K - all - in plus travel
	- Databubbles
	- 
	