#Interface Foundry 
October 24, 2014 - 11:07 AM

- Time
- Design assets
- Schedule
- demoing to Harvard Innovation Lab
- Table to sign people up
- Signage to email link - developer link to download the app. 
- CreateTech - other meetups 
- Ask the ticket holders to download the app
	- iOS compatible right now
- Stick to walls, 


