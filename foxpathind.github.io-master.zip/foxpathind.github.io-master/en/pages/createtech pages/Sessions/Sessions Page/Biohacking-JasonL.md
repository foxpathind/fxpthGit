#Biohacking: The Connected Human Experience
## Jason Levy, SVP, Experience Strategy & Innovation, Saatchi & Saatchi Wellness with Uwe Gutshcow,Head of Digital & Social Strategy, Managing Director, Creative Director, Innocean, Steven Dean, Partner, PreHype

Many predict human-hosted technology and connectivity as the next big evolution in both man and tech. Let’s explore the critical factors in the merger of man and machine. What it will mean for humans to be part of a connected world of intelligent things and places. What the experience design issues and opportunities are for players in this space. And ultimately, how a future where superhuman abilities further expanding the limits of mankind will impact us as communicators.
