#Mobility and The Connected Life
 
Entrepreneurs and established brands in financial services, retail, transportation, and health care are competing to develop their industries’ mobile game-changers.  In turn, mobile providers (wireless carriers, device manufacturers and operating systems) seek to forge new collaborations in these sectors (and others).  Join Jackie, Aditya [and Mark] to discuss mobile opportunities and challenges in the age of ubiquitous connectivity.
 
* Jackie McCarthy, Director of Wireless Internet Development, CTIA-The Wireless Association
*Aditya Khurjekar
*Mark Fitzgerald, Associate Director – Global Automotive Practice, Strategy Analytics