# The Connected Consumer. 
How a media agency and connected platform build insights and media programs based on mobility and movement. Mindshare and MapMyFitness talk about Life+ and how brands are leveraging new data to drive relevant brand experiences and how a connected platform reaches much more than the typical audience. Together, Jeff and Doug will talk about today’s landscape, how Mindshare and its wearables unit LIFE+ partner with Map My Fitness to uncover unexpected data correlations to reveal insights that drive successful campaigns. And, what is happening in our own backyard of Boston and what the data reveals.

Speakers:
Jeff Malmad, Mobile and Life+ lead, Mindshare North America
Doug Ziewacz, Sr. Director Sales, Connected Fitness 


[Helping Brands Engage in Connected Fitness](http://about.mapmyfitness.com/2013/10/connected-fitness-gathers-at-advertising-week/)
