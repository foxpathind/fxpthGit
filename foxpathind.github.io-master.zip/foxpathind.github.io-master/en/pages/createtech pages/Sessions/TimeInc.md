#Time inc
- Using data to distribute creative content across propoerties
- dynamic creative
- looking at the future of reading in a multi-screen world

