Tool of North America


- Storytelling + Technology - Talk about how we’ve done this across recent projects such as Remote Control Tourist, Taco Bell Snapchat and GT6 First Love. 

- The new IBM project we just launched.  It’s a cool story and we can get into the details of how it was made and collaboration with agency.  Maybe Ogivly would do the talk with us.  [James Murpgy, Tennis ball sounds and music Core77](http://www.core77.com/blog/technology/this_is_happening_james_murphy_remixing_tennis_the_sport_via_ibm_27550.asp
)

