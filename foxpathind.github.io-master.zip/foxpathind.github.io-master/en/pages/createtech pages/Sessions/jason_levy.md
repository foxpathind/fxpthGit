
October 21, 2014 - 3:07 PM

Jason Levy - bio hacking 
solid diffentiator
- two leads of the new york 
- i have notion around bio hacking 


Jason S - focusing on Brands in the space
- Oliver radical life extension - interesred
- Benjamin Mallory - digital astra zen - AZ
- Ellen Jorgenson
- IP department - patent 


## Jason Levy
### Future 15 at SXSW
- Biohacking group - Borg fest
- Steven Dean
- Antropological look 
	- from fringe to mainstream
	- implantable all signs point to inevitable
	- tinkering with themselves
	- transhumanism
	- technologists
		 
		 
		 
### Theme
- The connected human
- panelists


**Ellen Jorgensen**, Biologist and community science advocate (http://www.ted.com/talks/ellen\_jorgensen\_biohacking\_you\_can\_do\_it\_too)
 
**Lucas Dimoveo**, Project Manager, Grindhouse Wetwares (http://www.grindhousewetware.com/index.html)

### Bio hacking
- CreateTech theme No edges: humans+machines+environments
- A chance to explore the human side of the internet of everything, of a truly connected world
- Data contributor
- The body side of embodied intelligence
- Quantified self, to prosthetics, body enhancements
- What is possible? What is being done today? What will happen tomorrow?

### Lucas 
- Trends 
- There early on
- Background of bio-hacking 
- True belief in Transhumanism

