#Mindshare
## Idea 
### Presentation of original research
- Pool of million people 
- 5-10 questions on wearables or some headline
- Pitch to the press the minute of the conference 
- Reveal that press at conference
### MapMyFitness
- have participants take part in a run 
## september 22
- 
