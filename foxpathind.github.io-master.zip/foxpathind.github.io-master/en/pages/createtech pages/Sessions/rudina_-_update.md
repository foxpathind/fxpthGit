##Rudina - update

- Cynthia - confirmned
- Abby Fichner - confirmed 
- Dito labs - connected devices
	- get some volunteers
- 17th another update
	 