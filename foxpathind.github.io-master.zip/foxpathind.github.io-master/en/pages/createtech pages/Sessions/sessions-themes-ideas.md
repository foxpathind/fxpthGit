# the great synthesis
##on intgration
- vroom
- rishad article
- connection science
- where did the breakthroughs come from
	- tech enablement
	- connecting capabilities
	- moving power downstream
- what is the crap he speak of?

##the beginning
- design thinking
- embracing complexity
- beginners zen = curiosity
- honor discovery
- practice generosity

## the internet of everything is the big idea
- machine intelligence will migrate out of the enterprise
- from control of media to control of data and intepretation

## createtech
- we will explore the implications of these evolutions
- visualization will demonstrate what will soon be in everyones hands
- rich context awareness will drive the need for more sophisticated more appropriate forms of creative interactive, responsive, relevant, helpful


1. Data = sensing in a broad sense to create a picture of personal contexts for messaging, what are the best ad experience designs for the world data science is now giving us.
1.    Ad tech today is good business, what are the most promising technologies and future directions?
2.    How will the internet of things figure in this future?
2. Quantifed self and the customer conversation
1.    Services, products, brand experience
2.    What are the most important principles to guide our design strategies
3.    Projecting in and out, wearables, self and social behavior.
Wearables have at least two dimensions, first reporting the world to the wearer and second  signaling and acting on those around them through recording, messaging, etc. What are some questions for devices that do some of their work without the direct attention of the wearer, what are the feedback loops, the broader social impact?
3. Connected devices/environments
1.    Cars, car as media channel, car as iPhone, interaction design and daily life, brand experience and driving, how important is the connection experience to car brand experience.
2.    Connected appliances, what can we expect from the connected home and appliances
3.    Connective tissue; programming the internet of personal smart objects. Interoperability, data collections and aggregation, what are the upcoming consumer languages and tools.
4.    Virtual reality is a entire complete universe of connected and programmable things, including perhaps the people in universe. It also engages and empowers the body in new ways of interacting AND can also be connected to the physical world. There will be both physical and virtual interfaces to a connected world.
4. Innovation/agile creativity: project roles and agency skills, how are agencies retooling to produce more innovative work, sell it to clients and participate in the new creative age driven by digital, where entrepreneurship and programming are considered more creative than copywriting and art direction





  1.  Data = sensing in a broad sense to create a picture of personal contexts for messaging, what are the best ad experience designs for the world data science is now giving us
     *   Ad tech today is good business, what are the most promising technologies and future directions?
     *   How will the internet of things figure in this future?
  2.  Quantifed self and the customer conversation
     *   Services, products, brand experience
     *   What are the most important principles to guide our design strategies
  3.  Advances in connected cars, car as media channel,  car as iPhone, interaction design and daily life,, brand experience and driving,
     *   how important is the connection experience to car brand experience
  4.  Innovation agile creativity: project roles and agency skills, how are agencies retooling to  produce more innovative work, sell it to clients and participate in the new creative age driven by digital, where entrepreneurship and programming are considered more creative than copywriting and art direction
  5.  Projecting in and out wearables, self and social behavior, wearables have at least two dimensions, first reporting the world to the wearer and second  signaling and acting on those around them through recording, messaging, etc. What are some questions for devices that do some of their work without the direct attention of the wearer, what are the feedback loops
  6.  Virtual reality is a entire complete universe of connected and programmable things, Including perhaps the people in universe. It also engages and empowers the body in new ways of interacting AND can also be connected to the physical world. There will be both physical and virtual interfaces to a connected world.
  7.  Connected appliances, what can we expect from the connected home and appliances,
  8.  Connective tissue; programming the internet of personal smart objects. Interoperability, data collections and aggregation, what are the upcoming consumer languages and tools.