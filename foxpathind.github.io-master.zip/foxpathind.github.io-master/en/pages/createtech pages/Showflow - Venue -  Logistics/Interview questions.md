On Tuesday, November 11, 2014, Chessa Cahill <chessa@theboothphotovideo.com> wrote:
Hello Troy,

My name is Chessa and I am the Events Manager with The Booth.  I wanted to touch base to see if you had the interview questions for the video booth for us.  If you could send them my way I will make sure Ian and Jon have them for tomorrow.

I believe we have the questions for the speakers as:

What's the most interesting thing in your world?
What is your advice for the advertising industry?

But we need the questions for the general audience.  Please let me know if you have any questions.  Ian Londin will be your onsite contact tomorrow.  His cell is 914.646.5933

All the best,
Chessa

Chessa Cahill
The Booth
o: 914.305.2038
c: 914.646.0942
Web  I  Blog  I  Facebook



##Attendee
What's the coolest thing you heard today? 

What are you most excited about that you heard here today? 

Who was your favorite speaker and why?

What else would you like to see us do? Who else and what kind of speaker would you like to see at CreateTech?

Did you attend a workshop?  Should we consider expanding the idea of hands-on activities? 

Who else would you recommend come to CreateTech?

##Attendee - advertising professional

What's the coolest thing you heard today? 

What are you most excited about that you heard here today? 

Who was your favorite speaker and why?

"What about the future of advertising concerns you? 

What is the most over hyped trend in advertising?  

What is the most underrated technology? What are you most excited about?

What else would you like to see us do? Who else and what kind of speaker would you like to see at CreateTech?

Did you attend a workshop?  Should we consider expanding the idea of hands-on activities? 


Who else would you recommend come to CreateTech?


## Speaker - Not Advertising ##

What attracted you to speaking at CreateTe


How was your experience at the 4A's CreateTech?

What is your background and the field you're working in today?

What are some of the most exciting developments and challenges in the coming connected world?

What was the most exciting thing you heard at CreateTech?

What do you think the future holds for marketers in this world? What is their role and the role of advertising?



## Attendee - Creative Technologist/Manager ##

What is your background and how did you get into advertising?

What is your title now and your role in your agency?

What do think of CreateTech? Does it feel relevant to your work?

What was the coolest thing you've heard so far?

Who was your favorite speaker and why?

What else would you like to see us do? Who else and what kind of speaker would you like to see at CreateTech?





