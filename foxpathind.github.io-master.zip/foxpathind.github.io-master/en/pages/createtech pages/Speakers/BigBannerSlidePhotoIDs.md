## Slide 1 ##

Ben Malbon, Google
Cynthia Braezeal, JIBO
Rudina Seseri, Fairhaven Capital
Marcel Botha, Spuni

## Slide 2 ##

Abby Fichtner, Harvard Innovation lab
Mike Di Giovani, Isobar
Kati London, Microsoft Research, FUSE Lab
Sheldon Montiero, SapientNitro