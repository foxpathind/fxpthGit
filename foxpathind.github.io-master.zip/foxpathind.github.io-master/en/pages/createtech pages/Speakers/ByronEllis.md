
BYRON ELLIS
CTO
Spongecell

Byron Ellis is CTO of Spongecell, where he heads research and development. Prior to Spongecell, Byron served as Chief Data Scientist for LivePerson, a company that helps businesses engage in real-time customer communications. Byron also held various leadership positions at AdBrite, eventually serving as the company’s CTO. Byron holds a PhD in Statistics from Harvard University and was a postdoctoral fellow at Stanford Medical School. Byron earned a BS in Cybernetics from UCLA.