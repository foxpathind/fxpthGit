## CreateTech Checkin

### Thank for Participating in CreateTech
This year is shaping up into a great conference and we're very excited you're going to be a part of it. 

I’d love to get connected and talk about your presentation ideas 

Please contact me: (Chick: [cfoxgrover@aaaa.org][1])

#### Conference themes: Information for your talks

#### Things we will need from you
* [Check in at our speaker form: https://4a.wufoo.com/forms/4as-createtech2014-speaker-form/][2]
	* Bio and headshot, twitter etc
	* A/V requirements
	* Presentation title and upload 

[1]:	mailto:cfoxgrover@aaaa.org
[2]:	https://4a.wufoo.com/forms/4as-createtech2014-speaker-form/