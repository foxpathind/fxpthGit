# LaborDay week

## CreateTech follow ups

Name | contact | topic | status 
-----|---------|--------|-------
Fernanda | email | sent topics? | to speak
Ben Malbon | email/Alison | topics | to speak
Deltek |||
Hush |||
Critical Mass|||
Barbarian|||
Workman/manMade|||
Mark Logan|||
Nigel New Urban Mechanics|||

## Logistics
- MB outline
- reconcile schedules


## Website

### Book
### Interviews
### Analytics
### Taxonomy 
- 

## Department


