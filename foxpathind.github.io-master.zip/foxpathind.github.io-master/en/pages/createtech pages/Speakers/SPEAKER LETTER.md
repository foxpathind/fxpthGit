Thank you very much for taking the time to present at 4A's CreateTech 2014. As CreateTech is a few weeks away, we wanted to provide a few additional details for you. The dates of CreateTech are November 12 & 13 in Boston.

First, please take a few minutes to [complete our speaker information form](http://goo.gl/y3ITNH). This form is critical in putting on the best possible event for our attendees.

###[Online Speaker Form](http://goo.gl/y3ITNH)

Additional Details Below

You are currently scheduled to speak at {} on {}. Your session is listed as {}. Please check-in at the 4A's Registration Desk at least 30 minutes prior to your time on stage. We'll have talent wranglers to make sure you get to the stage on time.

###Venue
Microsoft NERD Center
1 Memorial Dr #1, 1st FL
Cambridge, MA 02142

###Onsite Contacts
Outside of Chick Foxgrover, your onsite contacts will be:
Troy Starwalt, tstarwalt@aaaa.org, 217-821-3167 (cell)
Patrick Conlin, pconlin@aaaa.org

Best,