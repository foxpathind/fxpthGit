

> **Location setup and A/V - Need a Boston coordinator** We may need some help on the anyone in Boston with a strong connection. The 4A's Events team will get engaged soon and I'll introduce everyone. We may need to hire a producer, a photographer and a video person for the two days.

* **Elliot and Arnold**  - 3 people to help
* Scott 


> **CreateTech Lab showcase - Need a Boston planner/coordinator** Want to consider having a "Show & Tell" area for Creative Technologies committee member agencies to show lab projects. Wanted to include 5 minute lightning rounds for Agency creative tech/innovation lab work but would be a lot of detail to organize. **Schedule may not allow it.** _**However, if there is interest in pursuing we might need some A/V help: computers and volunteer(s)**_

* **Elliot and Arnold**  - 3 people to help


> **Boston natives! Need Local hotel and attraction recommendations** to publish on the website and have to send out.

* **David S @ Mullen**


> **Thursday night end of conference party - Need a Boston planner/coordinator** (_need a Sponsor too!_) , Art&Code and/or Music&Code performance. We can curate through Leaders in software & Art or FakeLove or any other connections

* **Elliot and Arnold & Scott R and Hill Holiday**  - 3 people to help

> **Boston PR coordinate with Alison and 4A's

* **David S. @ Mullen**

![test image](imgs/4As-CreateTech-2014-468x60-1b6wx.gif)








