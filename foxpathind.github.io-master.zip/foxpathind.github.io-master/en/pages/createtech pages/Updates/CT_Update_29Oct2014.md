
September 22, 2014 - 11:33 AM

# Team

### 4A's ###



|**Name**|**Role**|**Email**|**Cell**| 
| ------	| ------	| ------	| ------	|  
|Chick Foxgrover|Program lead|cfoxgrover@aaaa.org|917-749-1792|  
|Michael Boyle|Event Project lead(not coming to CreateTech)|mboyle@aaaa.org| -?-|   
|Brenda Major|VP, Events (Boston native)|bmajor@aaaa.org| 908-8394731| 
|Troy Starwalt|Logistics & technical coordination, sponsorships|tstarwalt@aaaa.org| 217-821-3167|  
|Patrick Conlin|Technical lead/coordination|pconlin@aaaa.org| 949-436-9385| 


### Boston ###

|**Name**|**Agency**|**Role**|**Email**|**Cell**| 
| ------	| ------	| ------	| ------	|  
|David Swaebe|Mullen|Publicity and PR|dswaebe@mullen.com| -?-|  
|Mathew Ray|Mullen|Boston prgramming|mray@mullen.com| -?-|  
|Eliot Seaborn|Arnold|Boston programming|eseaborn@arn.com| -?-|  
|Scott Rabschnuk|Hill Holiday|Boston programming|scott.rabschnuk@hhcc.com| -?-|  
|Ginger Ludwig|Arnold|Boston coordination|gludwig@arn.com| -?-|  
|Josh Janicek|Arnold|Boston coordination|jjanicek@arn.com| -?-|  
|Catherine Phelan|Arnold|Boston admin|cphelan@arn.com| -?-|  
|Ebony Glass|Hill Holiday|Boston admin|Ebony.Glass@hhcc.com| -?-|

  
 

## Location and Venue: #


* Status: committed
	* Food and beverage - Breakfast and lunch, coffee, snacks all day

* **Location setup and A/V - Need a Boston coordinator**
	* Under control


* **Boston Accommodations**	
 
	* Agency materials on Welcome to Boston
 	 


## Attendees #

* **80** Seats sold
* Need 40-50 paid more
* Sales "pace" is slow!
* Boston agencies represented so far: Digitas, A-G, Arnold, Mullen, some HH
* Other Boston institutions desired
* VCs, startups, schools?


## Promotion#

#### Boston Media ? ####


* David Swaebe is connected to Alison Fahey 4A's CMO

#### Media Partners
* AdWeek
* 4A's SmartBrief
* SmartBrief ATMAE
* IAB SmartBrief 
* SmartBrief EdTech
* Mobile Media Summit
* Advertising Age

#### Other ####

* Weekly email marketing
* Tweet schedule


## Programming:

*  ***Programming finished***
*  Possibility of 2 slots for sponsors, special requests
*  New workshop: Agency Dev Ops - kbs+
* **CreateTech iBeacon/app prototype demo** Provided by Interface Foundry who will be in town to present to Harvard Innovation Lab.

### MCs ###

* I like to give Creative Technologies committee members opportunity to introduce the panels and speakers. If a participating (CreateTech or committee) Boston agency would like to have someone do this let me know.
	* **Coordinator ?** _Could use someone to gather the speaker info and distribute on cards to MCs_
* I think perhaps also the council should be represented as **hosts** of CreateTech. At the conference opening and end. 
	* **Candidates for opening and closing remarks**?



----
### Call In ###

October 29, 2014 - 1:37 PM

* Conference info
* Mass talent
	* promote the conference
	* distribution list
	* link to the site
* MITX 
	* Amy - give her heads up
* Targeted key companies
	* Fidelity
	* Outreach from the agencies
		* need the digital channels
* Giving agency committee
	* specific request
	* pick a slot
	* opening and closing
		* David and Mullen opening
		* Eliot Arnold closing
		* Scott board chair - 
		* Scott & David
* Sapient
	* Partnership 
* iProspect
	* 

