<div itemscope="" itemtype="http://schema.org/BusinessEvent">
<h1 itemprop="name">4A's CreateTech 2014</h1>

<p><span itemprop="startdate" content="2013-11-12T08:00">Novmeber 12-13</span>-
<span itemprop="enddate" content="2014-11_13T17:30">3</span>, 2014,<br />
<span itemprop="location" itemscope="" itemtype="http://schema.org/Place"><a itemprop="url" href="http://microsoftnewengland.com/">Micorosft NERD Center, Cambridge, MA</a></span><br />
<span itemprop="location" itemscope="" itemtype="http://schema.org/Place"><a itemprop="url" href="http://createtech.aaaa.org">http://createtech.aaaa.org</a></span></p>  
  </div>
  
  
  
  