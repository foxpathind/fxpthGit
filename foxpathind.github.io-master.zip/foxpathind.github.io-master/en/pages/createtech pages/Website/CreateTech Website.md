
# CreateTech Website
## Architcture
- Session descriptions
- Schedule
- Add the **TIMES**
- Speakers page
## Register button
## Blog post
- Internet of things reporting
- FastCompany, IoT, Boston the place to be
## Link to other groups
## Create breakfast/dinner groups
- IT
- Transhumanism
## Advertise Boston Groups
- meetups in your area
- Internet of things discussions