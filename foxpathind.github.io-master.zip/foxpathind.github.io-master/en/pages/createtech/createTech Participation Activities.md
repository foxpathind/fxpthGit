#createtech activities
## workshops
- audiences/levels
	- which staff
	- academic to entry level
- timings
- scaffolding
- principles to impart
	- experience design
	- collaboration
	- participatory design
	- use of new technology within everyday tasks of agency accounts
	- _project management accounting_ (needs to link out to seminars ) @seminars
 
##unconferences - issue based

##research
- getting feedback from agencies
- baseline audit
	- internal
	- external

##big issues
- creativity/innovation
- project management for CFOs @seminars
- coonected life series
- 
