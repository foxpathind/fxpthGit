4AsNotes/
4AsOperations/
4AsProjects/
4AsStrategy/
CF/
Ideas-Blog/
Internet of things/
MarkDown/
Meetings Correspondance/
Mobile App/
NOTES/
Research/
Scriv/
TO READ/
Templates/
Training Education/
VooDooPad/
WebsiteStrategy/
createtech pages/
createtech/
imgs/
meetings/
presos/
todo/
uploads/
wearables/
