## Drew ##

October 10, 2014  3:32 PM

- Call Alison
- Singapore was good
- CDX - Berlin next spring
- B2B in chicago
- Ritz Carlton
- Ritz Carlton - Berlin - mid May
	- Potsdamer Platz
	- E210
- CDX Silicon Valley
	- Moderate - native app
	- Postcards from Edge
		- Power of proximity
		- Real time 
		- CEA partner sean de bruback
		- seamus macatier
			- datasnap
		- car
		- wearable
	- in audience getting the audience
	- Jeremy give opinion and thoughts
- cover main night
