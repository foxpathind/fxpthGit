#Kitchen Cabinet
October 27, 2014 - 8:38 AM


##Projects
- Year in Review - mid jan. 5th - @tofollowup
	- Scheduling November 1
	- Editing
	- Outside video
- Dues process @tofollowup
- Survey on Member Usage and Evaluation
	- Brief
		- Perception image and reputation
		- Overall membership value - score
		- Outreach media agencies
	- net promoter score - service companies
	- Havas - needs to baseline
	- Time
- New marketing materials @tofollowup
	- Customize for digital
- Sponsorship materials @tofollowup


## Culture
- XChange - KC update meeting
- Webinar - webcast - made people proud
- do vertical webcasts @tofollowup


## Business Climate
- Revenue sources
	- Training
- Membership will be flat
- New business game - AdForum
- Add question about 4As membership on Search Consultants RFIs


## Membership
- Feel responsible



## CORE 
###Drivers
- Short fall


### Chart of "entities"
- All activities fall into these
	- encompassing - organizational work
		- Performance management
		- Culture
		- Job descriptions
		- Recruiting
		- Training
		- _Executing_
	- Image and perception of the 4A's
	- Membership
		- Enhance value proposition
		- Communications
		- Prospecting
		- Retaining
		- Training
	- Transformation
		- Programming
		- Logistics
		- Sponsorships
		- Marketing/Comm
		- Media
		- MPF
	- Image and reputation of the 4A's

### Financial
- Transformation
	- Attendance
	- Expense
	- Sponsorship
		- Commission - big $

### Board initiatives
- Measurement - how do we know
	- Marketing and Communications
	- Membership satisfaction
	- Media Outreach
- Millenials - Advocates
	- BK sees a revenue stream
	- a new organization?
	- feasibility study
	- business plan

## Top 3
### Mollie

#### Database
- Outside lists
 
###Tom F

###Alison F
- fully functioning communication
	- thought leadership
	- Nancy F
		- provocative
	- content plan part of website strategy
		- late 2015
		- schedule
		- member based content
			- ad of week
			- what are members are doing
			- adweek regional editions doesn't exist anymore
				- patch
			- media agencies
				- need to create content
				- language that doesn't pigeon hole
			- categories
		- segmentation versus integration
			- what is are offering
- Transformation
	- Branding internally
	- Agency room
	- Non media
		- creative partnership
	- sponsorships
		- materials for smaller business
		- resources on sales
		- dedicated sponsorship

### Singleton






