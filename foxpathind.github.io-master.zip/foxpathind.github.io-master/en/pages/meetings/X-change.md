October 28, 2014 - 10:08 AM

#LB
## KC recap
- Goals, KPIs and collaboration
- Chart 
## "What's on your mind?"
- Webinar
	- May me feel good
	- Too long
	- Make in smaller chunks, topic based
- Joe and website
	- resources and process
	- LB using the web site to get closer to our website
- Events 
	- ELP
	- on-premise event
		- event materials
	- CT
- Jim 
	- new terminale
	- webinars
## Make our expectations clear
- Everyone's responsibility
- Repeat back what you think is being asked
- Principles
	- time
	- quality
	- others needed
	- authority
- Accounting 
	- quarterly billing ready for December
- Year in Review
	
	






September 23, 2014 - 10:07 AM

#XChange
##Washington Update
- BK - New revenue streams
- BK - More authoritative role
- BK -More influence
- BK - Millenial program - BK's vision
	- underserved
	- find ways into a revenue stream 
	- include them into a membership model
	- drawn not just agencies but all marketing business
	- gathering place for the entire generation
	- Sylvain Research group
		- Facilitatd the sessions
		- Will deliver a business model
		- Revenue, maintenance, profit?
- Other projects
	- Mobile
	- Viewability
- Membership
	- Lost dues this year
		- Big losses, size of agencies etc
	- No clear trend in terms of agency profile of resigning agencies
	- Next generation of leaders
- Marketing plan
	- Advertising
		- Training program
- Financial presentation
	- Year of investment
	- Year of shortfall
	- But we now have the resources for our members and marketing
	- New and confidence building: media, memberships, marketing
	- Everything has to be on budget
		- Stratfest challenges
		- Training going well
		- Sponsorship
		- Transformation
	- Shift resources
		- To Alison 
		- To Bill Tucker
- Improvements
	- Website
	- Our "product"
	- Marketing
	- Make it happen and faster
##Staff reports
* IT expenses
* Mood
	* LR 
		* Busy
		* Marketing 
	* WK
		* Encouraged by new hires
		* Marketing and IT need to be unified
		* Need more info flowing from the membership team into our data
		* _LB - Mollie_ has been gathering intelligence
			* _"What are the field reps doing?"_ 
			* Listed meetings that they do, 100% of the time
			* They can't do the information gathering
			* _CF - Can we get the regional boards/councils to do the info gathering?_
			* We need more resources
				* Part of that is a better website - reach more people, emulate the member visit
	* LR
		* _We can't tell what is important, what is the value of work_
	* LB - the top 3's
		* Example: Mollie
			* Disciplined approach to prospecting
		* Example: Alison
			* Marketing plan
			* THEN implementing
			* Build department 
	* LR
		* Getting the big picture?
		* Project management?
		* Global Prioritization?
		
	
