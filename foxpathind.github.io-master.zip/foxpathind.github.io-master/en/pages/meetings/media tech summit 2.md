##You are the product
- vikram weather channel
-  weather based behavior
- travelers can use weather data and facebook connections of independent reps to deliver content through to people in the wave of a hurricane
- punching above the spending weight with mapping content to accessible context
- Lisa caputo !!! very smart
- Phil Wiser - Hearst 
	-  get deeper insights on interactions beyond the click through
	-  use our audience insight to deliver audiences through a trading desk
- weather, adjancies, science, animals etc
	- buy our our spot inventory in TV
	- applications to helps airlines, retailers etc. weather info is relevant to many kinds of activitees interactions others apps
	- geo important
- data and creative
	- creatives need to use the data
	- has been happening
	- LC : insights and data market research ground the creative
	- LC : allows segments
- creative process
	- you tube content,
	- feedback iterative
- personalization 
	- work long term?
	- hearst: facebook auto curating, consumers will expect
	- vikram need to use the data 
- better marketing
	- hearst will see things that will delight
	- data will enable mour conversation connected 
	- lc: iot more customer centered econmomy, away from product centricity
## conversation to conversion
- social taps into story telling human nature 
- speed of sharing story telling
- (the assumption is that there is a perfect product, commercial relationship for every need)
- social is not a channel
- social is about brands

## mobile ad panel
- skiptu
- viggle
### digital advertising
- verizon :ads on mobile are horrible
- consensus: quality must change
- 95 percent all ad spend is by 200 companies
- UX and analytics are sooner hires
- data ownership transparency is an issue
	- 
