# media tech summit
john honeycut discovery
deepa sureka rakuten
alton adams
------
analytics, data, currency
cmo cio
programmatic - need to understand, pockets of time, data 
rakuten : attribution and measurement power , 10 years experience, data challenge

the shift has happened, random access, 
how do we monetize, get access in this world

dmp's 
focusing on customers not channels
------
shelly
connected world
bob mudge verizon
"connectivity that makes sense"
how much bandwidth do you need
verizon
lte efficient
3-5 meg stream, all else is buffer
50 % usage increase year over year
fios is capacity, bavkbone, ladt mile and in the home, ecosystem, our focus is end to end 
announcing symmetrical speed quantum fiber router
	800 mbits
	guest password
	not a dumb pipe
	intelligent
coonected to lte network 65 channels stations outside the home on the fios 
out of the home content

shelly the car ultimate wearable

verizon: break out of the service provider
customer information 
see the content channels viewed
peak times
set top boxes use

------

context panel
larry kramer usa today
platform habits, content distribution, time to live
ads, they bought us, now looking for stronger intention, audience buying
losing the art of discovery?

shift toward value in value versus brute impression war for attention
branded content is only branded content if it sucks, otherwise just content

discovery. creepy or wonderful
how get users to choose us

(media's role how do they get into the owning cycle)

usa today, mobile = interactive, we need to get more personal to _compete _ with social
people look at a feed not for trusted headlines
psychological profile of context,content , strong POV versus learning

programmatic
over supply

great content, do clients or agencies care
content may be king but only in the right context

do we have the right kpis?

kyle sherman - impressions are worthless
brands will provide the content
adjacency opportunity is going away
advertsing doesnt belong in mobile
subscriptions and in app purchases, attention not worth anything

taboola
american express example now open forum
tech crunch wrote about louis ck, i want there
im optimistic about story telling
attention of people on your site, if you can provide value, 

brands have to change thenway they 

hour of programming hour of networking
	


