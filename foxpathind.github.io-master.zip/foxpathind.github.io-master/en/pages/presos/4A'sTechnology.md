# 4A's Technology Service Offering


---

# What Is a 4As Service #

- Communities of interest (committees)
- 


---

# The Chief Digital Officer Role #

The strategy and design of systems for:

- Business process
- Service
- Communication


---

# Current Projects #

- Creative Technology committee
	- Founded to recognize the rise of technology in agency offerings
	- Major effort: CreateTech conference, now in it's 4th year

---

# Some examples

- TechTalk
	- See out outline

---

# Some examples


- Munn Rabot
	- Storage strategies
		- Has come up often in IT committee
		- 22 Squared latest


---

# Some examples


- AHA
	- Payment dispute
		- Typical issues in Digital QA
		- Advice on determining breakdowns


---

# Some examples


- Data Security
	- Not legal advice!
	- Premeptive business processes and disclaimers


---

# Some examples

- Lauglin Constable
	- Project management methodologies dispute






---
