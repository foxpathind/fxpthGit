# Did you know?

---

## Syntax highlighting

It’s _**sooo easy**_ to show `codeSamples();` in your presentations. Deckset applies syntax highlighting and scales the type size so it always looks great.

---

### Hello World!

```javascript
function myFunction(){
	alert(“Hello World!”)
};
```

### **loooong** lines are scaled down

```objectivec 
UIView *someView = [[UIView alloc] init];
NSString *string = @"some string that is really, really, really really long, and has many, many, many words";
```
