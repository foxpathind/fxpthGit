- Nav is hierarchical. Terms form a network. Wiki words 
#TODO - END 2014

#Cross reference
|Name	| Session Title	| Date range	|???	|  
| ------	| ------	| ------	| ------	|  
|David Shrier	|Keynote	|Thursday	|entry	| 
|Dean	|Bio hacking Panel	|Thursday	|entry	|   

# Meetings/Calls:
	- Ray Velez @done
		- Experience design in advertising - lead a conversation
		- data and context, experience design
	- Tom Goodwin
		- Future of advertising
	- Isabel
		- Brownstein Ricoh billboard @emailed
			- Artist rep'ping
		- Dec. 9 change??



#Taxonomy:
	- Powershell
	- Sharepoin project 


#YIR:
	- Video assets??

#CES 2015:
	- [AppNation](http://appnationconference.com/an6/)
	 
		
		
#LifeBox personal infrastructure:
	- Zapier and Email to slack
	- model up!
	- 


#Monday Dec. 1:
	-  creative technologies deck to Mollie
	- CES panel
		- 
	- CreateTech meeting NYC Feb - Will be Feb 2
	- May in Berlin/Paris
	- Website update
		- Last board meeting
		- CMS evaluation
			- WordPress
			- Benel netFourm integration
		- Interviews  & Survey
		- Strategy outline
		- Content Strategy
	- Next steps
		- Features and functions
		- Design
		- UX - wireframes
	- Strategic implications, staffing and website design and build
		- CMS choice partially chosen for editors
		- Content creation editorial process influence what gets built
- - Craig Elmileah
	
#monday nov24:
	- Top 10 !!! @done
	- Finish highlights !!!
	- Appnation panel - 
	- Media, hardware platform, creative
	- Video editing
	- Wiki scripts
		- Folder of files to .md and place up a level
		-  Update nav.md
		- List of files to make cross links 
		- Network of files
	- Video
		- Website-
			- We've hired VML - get board outline
			- Finishing up the strategy phase
				- Some highlights
					- More friendly interface for our communications department who will be looking for highlighting news from our member agencies
					- Easier page layout for custom usage
					- Search by Categories  to provide easier access to 4As content and documents
					- Increased focus on the individual profile making visits to the 4As more valuable for members
		- CreateTech 2014
			- Best so far
			- Boston council pitched and supported our moving CreateTech this year to Boston
			- The creative technologies committee, which now has 25 members from agencies all over the country, gets together in early part fo the year to discuss an over all theme
			- After the dramatically increased coverage of wearables and new consumer internet of things products we decided to discuss the emerging connected world
			- Createtech is designed a s different kind of technology conference. We want a place for the professional technologists and manager with advanced topics, that also push into the speculative and the future, especially as it applies to the creative community
			- #####“Pervasive intelligence”: people, places, things
				- Dr. Cynthia Brazeal from MIT Media Lab who has invented a home robot name Jibo
				- Rudina Seseri from leads the media and technology practice at investment firm Fairhaven Capital 
				- Abby Fichtner, the hack in residence and the Hrvard Innovation Lab
			- #####Applications: knowledge, skills, working together
				- We heard from DeutschLA and Volkswagen on the important task of creating a car site site with many stakeholders.
				- A great story from ATT ManMadeMusic and Obscura Digital on using the entire Dallas Football stadium to dramtically enhance fan experience for tens of thousands
			- #####Our stories: client, agencies, consumers, ourselves
					- Fake Love, Hush and Obsura digital all artists who founded digital design agencies dedicated to experience design and have created some stunning work for brands.
			- Imagine the emerging world of connected people, places and things with thought-provoking technologists, artists, engineers, scientists, designers and programmers, managers and communicators.
			- There'll be sessions on civic interaction design, advanced agency creative technology management, dramatic brand experiences, biohacking and connection science, and much, much more.
#Monday Nov17:
	- Releases
	- Thank yous
	- Presentations
	- OpEd Summaries
	- Productivity Plan
		- ToDo tasks
		- Projects
		- Tags 
			- @ tags versus # tags
		- Structure
		- comms
			- email integratins
			- gathering contacts
			- managing threads/conversations vs managing tasks
		- mode switching in a common tongue - MD!! @md
	- Follow up thoughts
		- Jeffersonina dinners
		- Activity night - networking
			- How to guarantee an audience - @pr
			- How to guarantee the press - @pr
	- Followups
		- TOm F @done
		- Jeff @done
		- Ben M 
		- Sheldon
		- Alan S
		- 
	
#Projects:
	- Status monitoring
	- Taxonomy
		- Content inventory

	- Strategy Document
		- Overall goals
		- map to functions
		- create schedule
	- Improving netForum
		- Using netForum seminars
			- Weekly 15 minutes
			- Videos
		- Project List
		- Projects
			- What's required for a successful netForum project
	- CreateTech follow ups
		- 10 things
		- Videos
		- Presentations
		- 
	

# Dev Research:
- Check out elasticsearch.com some time. ELK is elasticsearch + logstash + kibana.
- RabitMQ



#Home:
	- Coffee order: http://shop.lacolombe.com/products/ethiopia-ardi
	- http://www.theroasterie.com/coffee/origin/ethiopia/ethiopia-sidamo
	- https://www.trebilcockcoffee.ca/coffee/ethiopian-sidama-ardi-detail

# ad tech review:
- audit issues and pubs
- categories
- managing an agency, managing creative work, managing client relationsips @strategic_concepts 
- Review sheldon's talk
	- move towards the system of ad technology management
- artists and artist run agencies
	- Fake love
	- Obscura Disgital
	- Sovrn State
	- Meta Agency
	- 

 


	

#Dates
|Name	| Session Title	| Date range	|???	|  
| ------	| ------	| ------	| ------	|  
|David Shrier	|Keynote	|Thursday	|entry	| 
|Dean	|Bio hacking Panel	|Thursday	|entry	|   

 


- Journalism program get back to ???

# General/On going:
- Wiki database of all sources for digital technology and advertising
	- Need namespace heirachy for all projects and information domains
	- Extensible
	- AdExchanger listing

	- 
## Calls/Meetings

Week of 19 Sep
- Sarah Hrusovsky <shrusovsky@powellny.com> re: Jason Levy @done
- Pam Lipshitz re: ATT and ManMade @done
- David Srier @done
- Pam Workman @done
- Call with Mike B. 9am 9/18 @done
- Nigel
- Write to Justin
	- Ray Velez
	- Anne at New School
- Brett Harned - HappyCog
- Nikki @ Tealium @CreateTech

## Connect:
- Brett Harned - HappyCog
- Nikki @ Tealium @CreateTech
- Chris Meija

# Technology and Development:
## Book For Georgia
Teach Yourself SQL in One Hour a Day @done

#Skills assessment:
## Skills assessment
- Get outline from Google Doc @done
- Prepare first outlines for courses
	- HTML
	- Database Concepts
	- Creative concepts




|Proposal|Contact|
|------|-------|
|Monotype | Jessie Hennion | @tofollowup
|Manmade music | Workman |
|Sheldon @Sapient | Alan | @tofollowup
|John Dain | 
|Tool, Ogilvy, IBM |
|FakeLove +1 |heather@doubleecomms| 
|Critical Mass | Critcal Mass|
|Barbarian Group| Barbarian |
|Digitas and Agile development|Andre| @done
|MEMI|Sarah Fay <sarah.fay@gmail.com> Cc: Amanda Neville <amanda.lee.neville@gmail.com>|
|Rodale guy| ?????|
|Michael Lebowitz - Big Spaceship | Powell |
|CTIA ?|||
|Chris Denson, OMD||


- 
|Time	| Session Title	| Duration	| People	|  
| ------	| ------	| ------	| ------	|  
|Entry	|entry	|entry	|entry	|  


## Tom Phelan
- Job Descriptions @done

## UX person for St Louis
- Write to Nathan S and Chris @done
- find out more about the ask @done
- Collect more names  @done
- Get names from email @done
- [Andrew Mullins] <am@timmermanngroup.com> 
- [Ries, Rhonda] <ries@osbornbarr.com>
- [Rosenfeld Experts](http://rosenfeldmedia.com/experts/)
- 

## Research 
- GigaOm

## Writing
- Blog post for CT site
- Architecture for CT Site

Education
## Education
- Justin hendrix
	-  Academic institutions
	- ACM SIG-CHI
	- Leader in Software and Art
- Mark Avnet and Advisory group wrote to singelton and Mark A @done
- find out about the feasibility study
- NYC media lab
- Shannon McPartlon
Director of Corporate and Foundation Relations
College for Creative Studies
201 East Kirby
Detroit, MI 48202
www.collegeforcreativestudies.edu

Phone: 313-664-7460
Fax: 313-664-7881




[acm
]

[youtube]


[acm]: http://dl.acm.org/results.cfm?CFID=421172645&CFTOKEN=61006122&query=&dl=GUIDE&dim=3215&dimoreprod=3215&dimgroup=3215&dimtab=3215
[acm 2]: http://dl.acm.org/citation.cfm?id=2633906&picked=prox&cfid=421172645&cftoken=61006122
[acm 3]: http://delivery.acm.org/10.1145/2600000/2591677/a14-kerne.pdf?ip=104.162.71.170&id=2591677&acc=ACTIVE%20SERVICE&key=4D4702B0C3E38B35%2E4D4702B0C3E38B35%2E7744629404986C95%2E4D4702B0C3E38B35&CFID=421172645&CFTOKEN=61006122&__acm__=1410144267_93299b25e7b44f2d07ad0aae0dedbf16
[acm 4]: http://dl.acm.org/citation.cfm?id=2556288.2557359&coll=DL&dl=GUIDE&CFID=421172645&CFTOKEN=61006122
[acm 5]: http://delivery.acm.org/10.1145/2560000/2557359/p2397-disalvo.pdf?ip=63.247.178.254&id=2557359&acc=ACTIVE%20SERVICE&key=4D4702B0C3E38B35%2E4D4702B0C3E38B35%2E7744629404986C95%2E4D4702B0C3E38B35&CFID=421172645&CFTOKEN=61006122&__acm__=1410202962_5f4ab6af15157719a1cc1e3fee5d8549
[dropbox]: https://www.dropbox.com/home/reference%20reading%20ebooks/QUADRANT/EmbodiedCognition
[github]: http://ericsson-innovate.github.io/hackathon-portal/#/sample-apps
[google]: https://mail.google.com/mail/u/0/?ui=2&pli=1#inbox
[google 2]: https://www.google.com/calendar/render?tab=mc&pli=1
[google 3]: https://www.google.com/hotels/?gl=US&cu_link=1&h=18240788802624997077#search;l=Cambridge,+Massachusetts;q=cambridge+MA+hotels;d=2014-11-11;n=3;usd=1;h=9217153625998340365;cuh=18240788802624997077;ph=0;si=455167aa;av=r
[google 4]: https://drive.google.com/a/aaaa.org/?tab=mo#shared-with-me
[google 5]: https://docs.google.com/a/aaaa.org/spreadsheets/d/18cabkvoFORNM-r9wc-8BAIgu9y-Qdd_rfpjS8Emb6Tk/edit#gid=0
[google 6]: https://docs.google.com/a/aaaa.org/document/d/1xQd94I3zhel203Ynq-QoWdiqm4lTsaRXkJHsiHKbLWM/edit#
[google 7]: https://docs.google.com/a/aaaa.org/spreadsheets/d/1192AKtC6UZxn9vJKHCM6DUZ35mMztY6CXpZDnq5-kZ8/edit#gid=0
[google 8]: https://support.google.com/accounts/answer/185833?hl=en
[googleratings]: https://survey.googleratings.com/wix/p7271318.aspx
[insight]: https://googleapps.insight.ly/User/Login?ReturnUrl=%2fMessages%2fdetails%2f16739437
[linkedin]: https://www.linkedin.com/profile/view?id=16619094&authType=NAME_SEARCH&authToken=p8YU&locale=en_US&trk=tyah2&trkInfo=tarId%3A1410207987777%2Ctas%3Ajason%20levy%2Cidx%3A1-1-1
[recode]: http://recode.net/2014/09/05/las-tech-startup-scene-is-coming-of-age/
[redbooth]: https://redbooth.com/a/#!/organizations
[rosenfeldmedia]: http://rosenfeldmedia.com/experts/
[sxsw]: http://panelpicker.sxsw.com/vote/22621


[aaaa]: http://createtech.aaaa.org/#createtech-2014-participate
[acm]: http://dl.acm.org/results.cfm?CFID=421172645&CFTOKEN=61006122&query=&dl=GUIDE&dim=3215&dimoreprod=3215&dimgroup=3215&dimtab=3215
[acm 2]: http://dl.acm.org/citation.cfm?id=2633906&picked=prox&cfid=421172645&cftoken=61006122
[acm 3]: http://delivery.acm.org/10.1145/2600000/2591677/a14-kerne.pdf?ip=104.162.71.170&id=2591677&acc=ACTIVE%20SERVICE&key=4D4702B0C3E38B35%2E4D4702B0C3E38B35%2E7744629404986C95%2E4D4702B0C3E38B35&CFID=421172645&CFTOKEN=61006122&__acm__=1410144267_93299b25e7b44f2d07ad0aae0dedbf16
[acm 4]: http://dl.acm.org/citation.cfm?id=2556288.2557359&coll=DL&dl=GUIDE&CFID=421172645&CFTOKEN=61006122
[dropbox]: https://blog.dropbox.com/2014/08/introducing-more-powerful-dropbox-pro/
[etherealmind]: http://etherealmind.com/
[foldingtext]: http://support.foldingtext.com/t/what-parts-of-multi-markdown-syntax-does-foldingtext-support/184
[google]: https://mail.google.com/mail/u/0/?ui=2&pli=1#inbox
[google 2]: https://www.google.com/calendar/render?tab=mc
[google 3]: https://drive.google.com/a/aaaa.org/?tab=mo#search/registration
[google 4]: https://docs.google.com/a/aaaa.org/document/d/1ubJ7koZ3jR6z56UiPG2xdFApKLBkjTnY9KyqL6c1bJs/edit
[google 5]: https://docs.google.com/a/aaaa.org/spreadsheet/ccc?key=0AolsLVLuBgcodGVKMEpiRUQ5X0FSY2dkQ1hpTC1vd0E&usp=drive_web#gid=4
[google 6]: https://docs.google.com/a/aaaa.org/spreadsheets/d/1192AKtC6UZxn9vJKHCM6DUZ35mMztY6CXpZDnq5-kZ8/edit#gid=0
[google 7]: https://support.google.com/accounts/answer/185833?hl=en
[google 8]: https://www.google.com/search?q=folding+text+and+markdown&oq=folding+text+and+markdown&aqs=chrome..69i57.5500j0j7&sourceid=chrome&es_sm=91&ie=UTF-8
[guidebook]: https://guidebook.com/pricing/
[insight]: https://googleapps.insight.ly/messages/details/16640146
[linkedin]: https://www.linkedin.com/home?trk=nav_responsive_tab_home
[redbooth]: https://redbooth.com/a/#!/organizations
[rosenfeldmedia]: http://rosenfeldmedia.com/experts/
[smcstl]: http://www.smcstl.com/new-events/2014/11/14/save-the-date-st-louis-digital-symposium
[thenextweb]: http://thenextweb.com/socialmedia/2014/09/07/guide-to-twitter-cards/?utm_source=newsletter&utm_medium=email&utm_campaign=37
[twitter]: https://twitter.com/search?q=%23STLDIGSYM&src=typd
[viddler]: http://www.viddler.com/videos/7632e10a/manage#ts-manage
[youtube]: https://www.youtube.com/watch?v=_ODFl4GUy8I

- 
