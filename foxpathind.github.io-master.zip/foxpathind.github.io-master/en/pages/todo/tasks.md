Website project
===============

Taxonomy
--------

### Sharepoint project

### Terms in Filemaker

Design
------

### Start book outline

Styles

Feature and functionality map
-----------------------------

### persona

### existing site

### Task 1

Admin
-----

### Budget

### Presentation

### Task 2

Creative Technologies
=====================

Feb 2
-----

Videos
------

Website
-------

Blogging
--------

CES
===

Appnation Panel
---------------
